"""Closed-form results from the ShipScatter paper (equation numbers refer to the manuscript)."""
import math
import numpy as np
from scipy.special import erfc, ndtri

C_SOUND = 1500.0  # m/s


def qfunc(x):
    return 0.5 * erfc(np.asarray(x) / math.sqrt(2))


def qinv(p):
    return -ndtri(p)


def kappa_single_harmonic(mu):
    """Fourth-moment penalty for one blade-rate harmonic of depth mu (below Eq. 8)."""
    return (1 + 3 * mu**2 + 3 * mu**4 / 8) / (1 + mu**2 / 2) ** 2


def g2_from_ts(ts_db, d):
    """Backscatter power ratio g^2 = 10^(TS/10)/d^2, d in metres (Eq. 4)."""
    return 10 ** (ts_db / 10) / d**2


def rho_frac(rho_db):
    """sigma_s^2/(sigma_s^2+sigma_w^2) from a ship-to-ambient ratio in dB."""
    r = 10 ** (np.asarray(rho_db) / 10)
    return r / (1 + r)


def snr_det(H, g2, rho=1.0, kappa=1.0):
    """Detection SNR of the single-lag differential correlator (Eq. 9)."""
    return H * g2 * rho**2 / (2 * (1 + (kappa - 1) * rho**2))


def ber_corr(H, g2, rho=1.0, kappa=1.0):
    return qfunc(np.sqrt(snr_det(H, g2, rho, kappa)))


def snr_energy_detector(H, g2, rho=1.0, kappa=1.0):
    """Energy detector without a reference hydrophone (Eq. 11): (g^2/2) * SNR_det."""
    return 0.5 * g2 * snr_det(H, g2, rho, kappa)


def rate_bps(B, g2, rho=1.0, kappa=1.0, p_target=1e-3):
    """Achievable rate for target error rate (Eq. 10), continuous K."""
    return B * g2 * rho**2 / (2 * qinv(p_target) ** 2 * (1 + (kappa - 1) * rho**2))


def backscatter_delay(ship, node, rx, fs, c=C_SOUND):
    """Excess backscatter delay in samples at the sensing hydrophone (Eq. 5). Inputs are 2-D/3-D positions."""
    ship, node, rx = (np.asarray(v, float) for v in (ship, node, rx))
    d = np.linalg.norm(node - rx)
    return fs * (np.linalg.norm(ship - node, axis=-1) + d - np.linalg.norm(ship - rx, axis=-1)) / c


def delay_span(d, fs, c=C_SOUND):
    return 2 * d * fs / c


def peak_drift(d, v, Dc, fs, c=C_SOUND):
    """Peak |dl/dt| in samples/s for a node on the track axis (Eq. 14)."""
    return fs * d * v / (c * Dc)


def drift_profile(R, d, v, Dc, fs, c=C_SOUND):
    return peak_drift(d, v, Dc, fs, c) * (Dc / np.asarray(R)) ** 3


def plate_ts_db(a, freq, c=C_SOUND, mod_allowance_db=6.0):
    """Flat-plate target strength 20log10(a^2/lambda) minus a modulation allowance.
    Upper bound when a is not much larger than the wavelength (see paper Sec. VI-H)."""
    lam = c / freq
    return 20 * math.log10(a**2 / lam) - mod_allowance_db


def direct_tx_electrical_power(range_m, alpha_db_per_km=0.2, eb_n0_db=10.0, noise_db=42.0,
                               rate_bps_=1.0, efficiency=0.3):
    """Table VIII: electrical power of a transmitter for 1 bit/s at the stated Eb/N0 (W)."""
    rx_level = noise_db + eb_n0_db  # dB re uPa^2 per second at 1 bit/s
    sl = rx_level + 20 * math.log10(range_m) + alpha_db_per_km * range_m / 1000.0
    p_ac = 10 ** ((sl - 170.8) / 10) * rate_bps_
    return sl, p_ac, p_ac / efficiency
