"""ShipScatter reference implementation: closed-form results and a sample-level Monte Carlo."""
from .theory import *  # noqa: F401,F403
