"""Sample-level Monte Carlo for the differential correlator and the energy detector
(single lag, Manchester coding; Sections III-IV of the paper). Integer lags only."""
import numpy as np


def carrier(n, fs, fb, mu, rng, harmonics=(1.0,), heavy_tail_sigma=0.0, block=20):
    """Blade-rate AM white-Gaussian carrier with E[m^2]=1 (Eq. 1); optional log-normal bursts."""
    t = np.arange(n) / fs
    m = 1 + sum(mu * h * np.cos(2 * np.pi * (i + 1) * fb * t + rng.uniform(0, 2 * np.pi))
                for i, h in enumerate(harmonics))
    m = m / np.sqrt(np.mean(m**2))
    s = m * rng.standard_normal(n)
    if heavy_tail_sigma > 0:
        u = np.exp(heavy_tail_sigma * rng.standard_normal(n // block + 1))
        u = np.repeat(u, block)[:n]
        s = s * u / np.sqrt(np.mean(u**2))
    return s


def run(g2, H=500, nbits=2000, rho_db=40.0, mu=0.5, fb=8.0, fs=2000.0, l_d=1, l_b=4,
        detector="correlator", heavy_tail_sigma=0.0, seed=0):
    rng = np.random.default_rng(seed)
    nper = 2 * H
    n = nbits * nper
    pad = 16
    s = carrier(n + 2 * pad, fs, fb, mu, rng, heavy_tail_sigma=heavy_tail_sigma)
    sw = 10 ** (-rho_db / 20)
    b = rng.integers(0, 2, nbits)
    chip = np.zeros((nbits, 2, H))
    chip[b == 1, 0, :] = 1
    chip[b == 0, 1, :] = 1
    chip = chip.reshape(-1)
    ref = s[pad:pad + n]
    direct = s[pad + l_b - l_d:pad + l_b - l_d + n]
    y_r = ref + sw * rng.standard_normal(n)
    y_s = direct + np.sqrt(g2) * chip * ref + sw * rng.standard_normal(n)
    if detector == "correlator":
        stat = (y_r * y_s).reshape(nbits, 2, H).sum(2)
    elif detector == "energy":
        stat = (y_s**2).reshape(nbits, 2, H).sum(2)
    else:
        raise ValueError(detector)
    bh = (stat[:, 0] - stat[:, 1] > 0).astype(int)
    errs = int(np.sum(bh != b))
    return errs / nbits, errs, nbits


def wilson(errs, n, z=1.96):
    p = errs / n
    den = 1 + z**2 / n
    c = (p + z**2 / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / den
    return max(0.0, c - h), min(1.0, c + h)
