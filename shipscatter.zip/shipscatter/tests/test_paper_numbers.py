import math
import numpy as np
from shipscatter import theory as T
from shipscatter import montecarlo as M


def test_kappa():
    assert abs(T.kappa_single_harmonic(0.5) - 1.40) < 0.01


def test_rate_baseline():  # paper: 0.94 bit/s (B=1 kHz, g2=0.025, rho=1, kappa=1.40, Pt=1e-3)
    assert abs(T.rate_bps(1000, 0.025, 1.0, 1.40) - 0.94) < 0.02


def test_energy_detector_loss():  # paper: 19.6 dB at g2=0.022
    loss = 10 * math.log10(T.snr_det(500, 0.022) / T.snr_energy_detector(500, 0.022))
    assert abs(loss - 19.6) < 0.1


def test_delay_span_and_drift():  # paper: span 5.3 samples; peak drift 0.13 samples/s
    assert abs(T.delay_span(2, 2000) - 5.33) < 0.01
    assert abs(T.peak_drift(2, 5, 100, 2000) - 0.133) < 0.002


def test_table_viii():  # SL 58/92/112/127 dB; 1 km electrical power ~4.5 uW
    for r, sl in [(2, 58), (100, 92), (1000, 112), (5000, 127)]:
        assert abs(T.direct_tx_electrical_power(r)[0] - sl) < 1.0
    assert 4.0e-6 < T.direct_tx_electrical_power(1000)[2] < 5.0e-6


def test_plate_ts():  # paper Table VII: -12, -24, -40, -52 dB for 50, 25, 10, 5 cm at 3 kHz
    for a, ts in [(0.5, -12), (0.25, -24), (0.10, -40), (0.05, -52)]:
        assert abs(T.plate_ts_db(a, 3000) - ts) < 0.5


def test_mc_matches_eq9_gaussian_like():
    # kappa for mu=0.5 is 1.40; MC error rate should be within a factor ~1.6 of Eq. 9 at moderate SNR
    g2 = 0.044
    ber, e, n = M.run(g2, nbits=4000, seed=3)
    pred = float(T.ber_corr(500, g2, 1.0, 1.40))
    assert ber < 5 * pred + 0.002


def test_reference_hydrophone_gain():
    # correlator is far better than energy detector at the same weak g2
    bc, *_ = M.run(0.044, nbits=1500, detector="correlator", seed=1)
    be, *_ = M.run(0.044, nbits=1500, detector="energy", seed=1)
    assert bc < 0.02 and be > 0.2
