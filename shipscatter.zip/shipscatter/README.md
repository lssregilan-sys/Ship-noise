# ShipScatter

Code accompanying *ShipScatter: Emission-Free Acoustic Backscatter Telemetry over Ships of Opportunity*
(R. Soosairaj; under review).

A node toggles its acoustic reflectivity; the carrier is the radiated noise of passing vessels; a
receiver with a reference and a sensing hydrophone recovers the bits by differential cross-correlation.

## What is in this repository

| Path | Contents |
|---|---|
| `shipscatter/theory.py` | Closed-form results: error rate (Eq. 9), rate (Eq. 10), energy detector (Eq. 11), delay law (Eq. 5), drift (Eq. 14), plate target strength, direct-transmission power (Table VIII) |
| `shipscatter/montecarlo.py` | Sample-level Monte Carlo of the single-lag correlator and the energy detector (Manchester coding, integer lags) |
| `scripts/replay_real_noise.py` | Replays **recorded** ship noise (ShipsEar, DeepShip, QiandaoEar22 WAV files) through the receiver and compares with Eq. (9) using the measured fourth-moment penalty |
| `scripts/ber_vs_g2.py` | Prints simulated vs. predicted error rate |
| `tests/test_paper_numbers.py` | Checks quoted paper numbers (0.94 bit/s, 19.6 dB, 5.3 samples, Table VII/VIII values) |

## Scope: please read

This repository is a **reference implementation of the closed-form analysis and the basic receiver**.
The full pass-level analysis (Tables V, VI, IX), the whitened multi-lag combiner, the decision-directed
delay tracker, clock recovery and lag-division access used for the manuscript's remaining figures are
**[AUTHOR: add the original simulation scripts to `full_simulation/` before release, or delete this sentence
if they are already included]**. Do not claim that this repository alone reproduces every figure.

## Quick start

```bash
pip install -r requirements.txt
python scripts/ber_vs_g2.py
python -m pytest            # or: python tests/test_paper_numbers.py functions run individually
```

## Recorded-noise replay

```bash
python scripts/replay_real_noise.py --selftest
python scripts/replay_real_noise.py --wav data/ship1.wav data/ship2.wav --band 100 1000 --rho-db 10 --out results.json
```

Audio files are **not** included. Obtain them from the original providers under their licences
(ShipsEar: University of Vigo; DeepShip; QiandaoEar22) and place them in `data/` (git-ignored).
Limitations of the replay: integer lags, a 100–1000 Hz band instead of the 3 kHz band of the manuscript's
Table II, global half-symbol length, no propagation.

## Citation

See `CITATION.cff`. After the first GitHub release, archive it on Zenodo and put the DOI in the
manuscript's *Reproducibility* paragraph and in `CITATION.cff`.

## Licence

MIT (see `LICENSE`).
