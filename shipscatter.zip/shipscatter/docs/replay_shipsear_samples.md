# Replay on four ShipsEar sample files (rho = 10 dB, H = 500, 20 x 100-bit segments per point)

Files: 22 adventure_maniobra (54 s), 6 marDeCangas_Entra (301 s), 79 H3_zodiac (100 s), 82 H3_lluvia (120 s, **rain, not a vessel**; used as a non-ship control).
BER = mean over 20 random segments of 100 bits (2000 bits per point; segments overlap within a file, and the 54 s file offers essentially one window).

| file | kappa_tot raw | BER plain g2=0.044 | BER envnorm g2=0.044 | Eq.9(kappa_meas) | Eq.9(Gauss) | BER plain g2=0.35 |
|---|---|---|---|---|---|---|
| adventure | 1.46 | 0.048 | 0.036 | 0.005 | 0.0013 | 0.000 |
| marDeCangas | 4.54 | 0.062 | 0.050 | 0.064 | 0.0013 | 0.018 |
| zodiac | 2.31 | 0.014 | 0.013 | 0.018 | 0.0013 | 0.000 |
| rain (control) | 3.49 | 0.114 | 0.046 | 0.042 | 0.0013 | 0.015 |
Full tables: replay_shipsear_samples.json.
