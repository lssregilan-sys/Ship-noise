"""Batch replay: several random segments per WAV, averaged. Usage: python run_replay_batch.py DIR_WITH_WAVS [out.json]"""
import sys, os, json, glob, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import replay_real_noise as R
d = sys.argv[1]; outp = sys.argv[2] if len(sys.argv) > 2 else "replay_batch.json"
G2 = [0.022, 0.044, 0.088, 0.176, 0.35]; RHO = 10.0; H = 500; NB = 100; REPS = 20
out = []
for p in sorted(glob.glob(os.path.join(d, "*.wav"))):
    s, fs = R.load_carrier(p, (100, 1000)); res = {"name": os.path.basename(p), "dur_s": len(s) / fs}
    for tag, x in (("raw", s), ("whitened", R.whiten(s))):
        kap = R.kappa_tot(x); rows = []
        for g2 in G2:
            pl = [R.simulate_ber(x, g2, RHO, H, NB, np.random.default_rng(1000 + r)) for r in range(REPS)]
            en = [R.simulate_ber(x, g2, RHO, H, NB, np.random.default_rng(1000 + r), normalise=True) for r in range(REPS)]
            rows.append(dict(g2=g2, ber_plain=float(np.mean(pl)), ber_envnorm=float(np.mean(en)),
                             th_kappa=R.eq9(g2, RHO, H, kap), th_gauss=R.eq9(g2, RHO, H, 1.0)))
        res[tag] = dict(kappa=kap, rows=rows)
    out.append(res)
json.dump(out, open(outp, "w"), indent=1)
