"""Print simulated vs. Eq. (9) error rate for the correlator and the energy detector."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from shipscatter import theory as T, montecarlo as M

print("g2      corr_MC  corr_Eq9  ED_MC")
for g2 in [0.022, 0.044, 0.088, 0.176, 0.35]:
    c, *_ = M.run(g2, nbits=3000, detector="correlator")
    e, *_ = M.run(g2, nbits=3000, detector="energy")
    print(f"{g2:.3f}  {c:.4f}   {float(T.ber_corr(500, g2, 1.0, 1.40)):.4f}    {e:.4f}")
