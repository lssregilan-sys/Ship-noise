#!/usr/bin/env python3
"""
ShipScatter: replay RECORDED ship noise through the differential-correlator receiver.

Purpose
-------
The paper's Monte Carlo draws the carrier from the same model the theory assumes, so it
validates the algebra only. This script replaces the synthetic carrier s[n] with a real
ship-radiated-noise recording (ShipsEar / DeepShip / QiandaoEar22 WAV files) and keeps
everything else of Eqs. (1)-(9) unchanged:

    y_r[n] = s[n] + w_r[n]
    y_s[n] = a*s[n-l_d] + g*b[n]*s[n-l_b] + w_s[n]        (integer lags l_d=1, l_b=4)
    D_k    = sum_{half 1} y_r[n] y_s[n+l_b] - sum_{half 2} y_r[n] y_s[n+l_b]   (Manchester)

For each recording it reports, versus g^2:
  * measured BER of the plain single-lag correlator,
  * measured BER of the envelope-normalised correlator (Sec. IV-D),
  * Eq. (9) prediction using the MEASURED fourth-moment penalty kappa_tot of that recording,
  * the stationary-Gaussian prediction (kappa = 1).
Agreement between the measured BER and the kappa_tot-based prediction on real data is the
evidence that the analysis survives a real carrier; disagreement is a finding to report.

Usage
-----
  python replay_real_noise.py --selftest                      # code check on a synthetic stand-in
  python replay_real_noise.py --wav a.wav b.wav --band 100 1000 --out results.json
  (WAV files: ShipsEar recordings are 52.7 kHz mono; any rate is resampled to fs = 2*band_hi.)

Requires numpy, scipy.  Optional: soundfile (else scipy.io.wavfile is used).
"""
import argparse, json, math, sys
import numpy as np
from scipy import signal
from scipy.special import erfc


def qfunc(x):
    return 0.5 * erfc(x / math.sqrt(2))


# --------------------------------------------------------------------------- carrier
def load_carrier(path, band, seconds=None):
    """Load WAV, band-limit to [lo,hi] Hz, resample to fs=2*hi, unit power."""
    try:
        import soundfile as sf
        x, fs0 = sf.read(path, always_2d=False)
    except Exception:
        from scipy.io import wavfile
        fs0, x = wavfile.read(path)
        x = x.astype(np.float64)
        if x.dtype.kind in "iu":
            x /= np.iinfo(x.dtype).max
    if x.ndim > 1:
        x = x[:, 0]
    x = np.asarray(x, dtype=np.float64)
    if seconds:
        x = x[: int(seconds * fs0)]
    lo, hi = band
    fs = 2 * hi
    sos = signal.butter(8, [lo, min(hi, 0.99 * fs0 / 2)], btype="band", fs=fs0, output="sos")
    x = signal.sosfiltfilt(sos, x)
    g = math.gcd(int(fs), int(fs0))
    x = signal.resample_poly(x, int(fs) // g, int(fs0) // g)
    x = x - x.mean()
    x /= np.sqrt(np.mean(x ** 2)) + 1e-30
    return x, fs


def whiten(x, nfft=1024):
    """Spectral whitening (receiver-side pre-whitening) using a smoothed Welch PSD."""
    f, p = signal.welch(x, nperseg=nfft)
    p = np.convolve(p, np.ones(9) / 9, mode="same")
    # floor the PSD relative to its median so out-of-band bins (near-zero power after the
    # band-pass) are not boosted into the carrier; this keeps the whitener bounded.
    p = np.maximum(p, 1e-2 * np.median(p)) + 1e-30
    h = np.fft.irfft(1.0 / np.sqrt(p), n=nfft)
    h = np.fft.fftshift(h) * signal.windows.hann(nfft)
    y = signal.fftconvolve(x, h, mode="same")
    return y / np.sqrt(np.mean(y ** 2))


def kappa_tot(s, win=64):
    """Fourth-moment penalty kappa_tot = E[s^4]/(3 E[s^2]^2): equals 1 for stationary Gaussian."""
    return float(np.mean(s ** 4) / (3.0 * np.mean(s ** 2) ** 2))


def env_normalise(y, win=64):
    e = np.sqrt(signal.fftconvolve(y ** 2, np.ones(win) / win, mode="same")) + 1e-9
    return y / e


# --------------------------------------------------------------------------- link simulation
def simulate_ber(s, g2, rho_db, H, nbits, rng, l_d=1, l_b=4, a=1.0, normalise=False):
    """Differential-correlator BER with the recorded carrier s (unit power).
    rho_db: ship-to-ambient power ratio at the hydrophones (carrier vs. white ambient noise)."""
    rho = 10 ** (rho_db / 10)
    sig_w = math.sqrt(1.0 / rho)  # ambient noise std for carrier power 1
    nper = 2 * H
    need = nbits * nper + 32
    # use a random contiguous start in the recording, wrapping if needed
    start = rng.integers(0, max(1, len(s) - need)) if len(s) > need else 0
    seg = s[start:start + need] if len(s) >= start + need else np.resize(s, need)
    b = rng.integers(0, 2, nbits)
    chip = np.empty(nbits * nper)
    for k in range(nbits):  # Manchester: 1 -> [1,0], 0 -> [0,1]
        first, second = (1, 0) if b[k] else (0, 1)
        chip[k * nper:k * nper + H] = first
        chip[k * nper + H:(k + 1) * nper] = second
    n = nbits * nper
    s_ref = seg[16:16 + n]
    s_d = seg[16 - l_d:16 - l_d + n]
    s_b = seg[16 - l_b:16 - l_b + n]
    g = math.sqrt(g2)
    # sensing hydrophone: direct (+ delayed), backscatter, noise
    y_r = s_ref + sig_w * rng.standard_normal(n)
    # y_s evaluated at n + l_b: direct path is s[n+l_b-l_d]; backscatter is g*b*s[n]
    s_dir = seg[16 + l_b - l_d:16 + l_b - l_d + n]
    y_s = a * s_dir + g * chip * s_ref + sig_w * rng.standard_normal(n)
    if normalise:
        y_r = env_normalise(y_r)
        y_s = env_normalise(y_s)
    p = (y_r * y_s).reshape(nbits, 2, H).sum(axis=2)
    D = p[:, 0] - p[:, 1]
    bhat = (D > 0).astype(int)
    return float(np.mean(bhat != b))


def eq9(g2, rho_db, H, kap):
    rho = 10 ** (rho_db / 10) / (1 + 10 ** (rho_db / 10))  # sigma_s^2/(sigma_s^2+sigma_w^2)
    snr = H * g2 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2))
    return float(qfunc(math.sqrt(snr)))


# --------------------------------------------------------------------------- driver
def run_one(name, s, g2_list, rho_db, H, nbits, seed, do_whiten=True):
    rng = np.random.default_rng(seed)
    out = {"name": name, "n_samples": int(len(s))}
    for tag, x in (("raw", s), ("whitened", whiten(s) if do_whiten else None)):
        if x is None:
            continue
        kap = kappa_tot(x)
        rows = []
        for g2 in g2_list:
            row = {"g2": g2,
                   "ber_plain": simulate_ber(x, g2, rho_db, H, nbits, rng),
                   "ber_envnorm": simulate_ber(x, g2, rho_db, H, nbits, rng, normalise=True),
                   "theory_kappa_measured": eq9(g2, rho_db, H, kap),
                   "theory_gaussian": eq9(g2, rho_db, H, 1.0)}
            rows.append(row)
        out[tag] = {"kappa_tot": kap, "rows": rows}
    return out


def synthetic_standin(fs=2000, seconds=600, seed=0, bursty=True):
    """NOT real data. Stand-in used only to test the code path: coloured noise + blade-rate
    modulation + log-normal bursts. Real recordings replace this."""
    rng = np.random.default_rng(seed)
    n = fs * seconds
    x = signal.lfilter([1], [1, -0.6], rng.standard_normal(n))
    t = np.arange(n) / fs
    m = 1 + 0.5 * np.cos(2 * np.pi * 8 * t)
    x = x * m
    if bursty:
        blocks = np.exp(0.6 * rng.standard_normal(n // 20 + 1))
        x = x * np.repeat(blocks, 20)[:n]
    x -= x.mean()
    return x / np.sqrt(np.mean(x ** 2)), fs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wav", nargs="*", default=[])
    ap.add_argument("--band", nargs=2, type=float, default=[100.0, 1000.0])
    ap.add_argument("--rho-db", type=float, default=10.0, help="ship-to-ambient ratio [dB]")
    ap.add_argument("--H", type=int, default=500, help="samples per half-symbol (paper: 500)")
    ap.add_argument("--nbits", type=int, default=2000)
    ap.add_argument("--g2", nargs="*", type=float, default=[0.022, 0.044, 0.088, 0.176])
    ap.add_argument("--seconds", type=float, default=None, help="limit seconds read per file")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--out", default="replay_results.json")
    a = ap.parse_args()

    results = []
    if a.selftest:
        # (1) stationary Gaussian carrier: simulation must match Eq. (9) with kappa=1
        rng = np.random.default_rng(5)
        g = rng.standard_normal(2000 * 600)
        results.append(run_one("selftest_white_gaussian", g / g.std(), a.g2, a.rho_db, a.H, a.nbits, a.seed, False))
        # (2) bursty coloured stand-in (SYNTHETIC)
        s, _ = synthetic_standin()
        results.append(run_one("selftest_bursty_coloured_STANDIN", s, a.g2, a.rho_db, a.H, a.nbits, a.seed))
    for p in a.wav:
        s, fs = load_carrier(p, tuple(a.band), a.seconds)
        results.append(run_one(p, s, a.g2, a.rho_db, a.H, a.nbits, a.seed))

    if not results:
        sys.exit("nothing to do: give --wav files or --selftest")
    with open(a.out, "w") as f:
        json.dump(results, f, indent=1)
    for r in results:
        print(f"\n== {r['name']} ==")
        for tag in ("raw", "whitened"):
            if tag not in r:
                continue
            print(f" [{tag}] kappa_tot = {r[tag]['kappa_tot']:.2f}")
            print("   g2     plain    envnorm  theory(kappa_meas)  theory(Gauss)")
            for row in r[tag]["rows"]:
                print(f"  {row['g2']:.3f}  {row['ber_plain']:.4f}  {row['ber_envnorm']:.4f}   "
                      f"{row['theory_kappa_measured']:.4f}            {row['theory_gaussian']:.4f}")


if __name__ == "__main__":
    main()
