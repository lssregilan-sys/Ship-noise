import numpy as np, json, sys, time
from sim2 import *
g = sys.argv[1]
rng = np.random.default_rng({'X': 1, 'Y': 2, 'Z': 3}[g])
t0 = time.time(); out = {}
def b(c, pol, nt, **kw):
    e, n = run_trials(c, pol, nt, rng, **kw); return round(e / n, 4)
if g == 'X':
    for name, kw in {'base': {}, 'heavy': dict(heavy=True), 'combined': dict(mus=[0.5, 0.25, 0.12], heavy=True, tonal=0.1, drift=0.05)}.items():
        c = cfgx(**kw)
        out[name] = dict(plain=b(c, 'fixed1', 500), norm=b(c, 'fixed1', 500, norm=True))
        print(name, out[name], f"{time.time()-t0:.0f}s", flush=True)
if g == 'Y':
    P3 = [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)]
    P5 = [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)]
    for nm, tp in (('P3', P3), ('P5', P5)):
        for npre in (16, 32):
            c = cfgx(taps=tp, direct=[(1.0, 1.0), (3.1, 0.5)], npre=npre)
            r = dict(thresh=b(c, 'thresh', 400))
            for beta in (0.02, 0.05):
                r[f'track_b{beta}'] = b(c, 'track', 400, beta=beta)
            out[f'{nm}_pre{npre}'] = r
            print(nm, npre, r, f"{time.time()-t0:.0f}s", flush=True)
if g == 'Z':
    for ramp in (0.25, 0.5):
        c = cfgx(ramp=ramp)
        for L in (5, 7):
            for beta in (0.15, 0.3, 0.5):
                out[f'ramp{ramp}_L{L}_b{beta}'] = b(c, 'trackw', 300, lags=range(0, 48), L=L, beta=beta)
                print(ramp, L, beta, out[f'ramp{ramp}_L{L}_b{beta}'], f"{time.time()-t0:.0f}s", flush=True)
json.dump(out, open(f'tune_{g}.json', 'w'), indent=1)
