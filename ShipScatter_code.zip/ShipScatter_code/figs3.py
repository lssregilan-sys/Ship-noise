import json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shipscatter import theory_ber
plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 200, "legend.frameon": False})
C = ["#1f4e9c", "#d1495b", "#2a9d8f", "#e9a03b", "#6a4c93", "#777777"]
V = json.load(open('v3_results.json')); V4 = json.load(open('v4_results.json')); mc = json.load(open('mc_results.json'))
import exp_v3 as X
# live-theory comparison for Fig 3
e2 = mc['E2']; g2 = 2 * 10 ** 0.9 / 500
live = [theory_ber(4, g2, 10 ** (-x / 10), 0.5) for x in e2['ship_to_noise_db']]
json.dump(dict(snr=e2['ship_to_noise_db'], mc=e2['mc'], live=live), open('fig3_live.json', 'w'))
print([ (x, round(m, 4), round(t, 4)) for x, m, t in zip(e2['ship_to_noise_db'], e2['mc'], live)])
# ---- Fig 12: geometry ----
fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.9))
ax = axs[0]
for th, c, lab in ((0, C[3], 'axis along track (θ = 0°)'), (90, C[1], 'node on lane side (θ = 90°)'), (270, C[0], 'node on far side (θ = 270°)')):
    t, R, l, dl = X.geom(5, 100, th)
    ax.plot(t, l, color=c, label=lab)
ax.axhline(X.LMIN, color='k', ls=':', lw=1); ax.text(-590, 1.08, 'below 1 sample: collides with direct-path lag', fontsize=6.5)
ax.set_xlim(-600, 600); ax.set_xlabel('time relative to closest approach (s)'); ax.set_ylabel('backscatter lag (samples)')
ax.set_title('(a) lag during a 5 m/s pass, CPA 100 m', fontsize=8); ax.legend(fontsize=6.5, loc='center right', bbox_to_anchor=(1.0, 0.42))
ax = axs[1]
o = next(r for r in V4['orient'] if r['v'] == 5 and r['Dc'] == 100)
th = [p['th'] for p in o['per']]; ax.plot(th, [p['link'] for p in o['per']], color=C[0], label='coded, normalised receiver')
ax.plot(th, [p['unc'] for p in o['per']], color=C[1], label='uncoded, plain receiver')
ax.set_xlabel('node bearing θ (deg)'); ax.set_ylabel('reports per pass'); ax.set_xticks([0, 90, 180, 270, 360])
ax.set_title('(b) reports versus node bearing', fontsize=8); ax.legend(fontsize=7, loc='lower right'); ax.set_ylim(0, 52); ax.axhline(o['ideal']['link'], color='k', ls=':', lw=1)
fig.tight_layout(); fig.savefig('fig12_geometry.png'); plt.close(fig)
# ---- Fig 13: TS sweep and transmit baseline ----
fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.9))
ax = axs[0]
tsv = [r['ts'] for r in V4['ts'] if r['ts'] >= -40]
ax.semilogy(tsv, [r['coded'] for r in V4['ts'] if r['ts'] >= -40], 'o-', color=C[0], ms=4, label='coded, normalised')
ax.semilogy(tsv, [r['unc'] for r in V4['ts'] if r['ts'] >= -40], 's-', color=C[1], ms=4, label='uncoded, plain')
ax.axhline(1, color='k', ls=':', lw=1); ax.text(-39, 1.2, 'one report per pass', fontsize=7)
for a, ts in ((0.5, -12), (0.25, -24)): ax.axvline(ts, color=C[5], ls='--', lw=0.8); ax.text(ts - 0.5, 0.03, f'{int(a*100)} cm plate', fontsize=6.5, rotation=90, va='bottom', ha='right')
ax.set_xlabel('differential target strength TS$_{mod}$ (dB re 1 m)'); ax.set_ylabel('reports per pass'); ax.set_ylim(0.02, 120)
ax.set_title('(a) 5 m/s, CPA 100 m, node on far side', fontsize=8); ax.legend(fontsize=7, loc='upper left')
ax = axs[1]
d = np.array([r['d'] for r in V['tx']]); pe = np.array([r['P_el'] for r in V['tx']])
ax.loglog(d, pe * 1e6, 'o-', color=C[2], ms=4, label='active transmitter, 30% efficiency')
ax.axhline(5, color=C[1], ls='--', label='ShipScatter node, 5 µW (assumed)')
ax.set_xlabel('range (m)'); ax.set_ylabel('electrical power for 1 bit/s (µW)'); ax.set_title('(b) radiated-power cost of direct transmission', fontsize=8)
ax.legend(fontsize=7, loc='upper left')
fig.tight_layout(); fig.savefig('fig13_ts_tx.png'); plt.close(fig)
# ---- Fig 10 replacement: rate map, TS to -40 ----
fig, ax = plt.subplots(figsize=(4.8, 3.3))
ts = np.linspace(-45, 0, 200); dd = np.logspace(np.log10(0.25), np.log10(10), 200)
T, Dm = np.meshgrid(ts, dd)
from scipy.special import erfcinv
Qinv = lambda p: np.sqrt(2) * erfcinv(2 * p)
R = 1000 * 10 ** (T / 10) / Dm ** 2 / (2 * Qinv(1e-3) ** 2 * 1.4)
cs = ax.contourf(T, np.log10(Dm), np.log10(R), levels=np.arange(-6, 3.1, 1), cmap='viridis')
cb = fig.colorbar(cs, ax=ax); cb.set_label('log$_{10}$ rate (bit/s)')
ax.contour(T, np.log10(Dm), np.log10(R), levels=[np.log10(0.025)], colors='w', linewidths=1.5)
ax.text(-44.5, np.log10(0.28), '≈ 1 report/pass (5 m/s, CPA 100 m)', color='w', fontsize=7, rotation=0)
for a, tsp in ((0.1, -40), (0.25, -24), (0.5, -12)): ax.plot([tsp], [np.log10(2)], 'o', color='w', ms=4); ax.text(tsp, np.log10(2) + 0.06, f'{int(a*100)} cm', color='w', fontsize=6.5, ha='center')
ax.set_yticks(np.log10([0.25, 0.5, 1, 2, 5, 10])); ax.set_yticklabels(['0.25', '0.5', '1', '2', '5', '10'])
ax.set_xlabel('TS$_{mod}$ (dB re 1 m)'); ax.set_ylabel('node–receiver spacing (m)')
fig.tight_layout(); fig.savefig('fig11_design.png'); plt.close(fig)
