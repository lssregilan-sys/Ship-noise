import numpy as np, json
from shipscatter import ship_noise, FS, FB, Q
from sim2 import wilson
rng = np.random.default_rng(91); K = 4; H = int(round(K / (2 * FB) * FS))
def link(nb, g, LB, LD, sw2=1e-3, mu=0.5):
    bits = rng.integers(0, 2, nb); n = nb * 2 * H + 64
    S = ship_noise(n + 16, mu, rng); sw = np.sqrt(sw2)
    pat = np.empty((nb, 2 * H)); pat[:, :H] = bits[:, None]; pat[:, H:] = 1 - bits[:, None]
    b = np.zeros(n); b[:nb * 2 * H] = pat.reshape(-1)
    ref = S[8:8 + n] + sw * rng.standard_normal(n)
    y = S[8 - LD:8 - LD + n] + g * b * S[8 - LB:8 - LB + n] + sw * rng.standard_normal(n)
    # detector at lag LB; LB may equal the direct lag LD (b-independent direct correlation then adds variance)
    prod = ref[:n - LB] * y[LB:]; prod = np.concatenate([prod, np.zeros(LB)])[:nb * 2 * H].reshape(nb, 2, H).sum(axis=2)
    return int(np.sum(((prod[:, 0] - prod[:, 1]) > 0).astype(int) != bits)), nb
out = {}
for g2 in (0.044,):
    g = np.sqrt(g2)
    for name, LB, LD in (('lag 4, direct 1 (separated)', 4, 1), ('lag 2, direct 1', 2, 1), ('lag 1 = direct lag 1 (collision)', 1, 1), ('lag 0, direct 1', 0, 1)):
        e = t = 0
        for _ in range(60):
            a, b_ = link(400, g, LB, LD); e += a; t += b_
        lo, hi = wilson(e, t); out[name] = dict(ber=e / t, lo=lo, hi=hi, n=t); print(name, e / t, flush=True)
json.dump(out, open('v3_dcoll.json', 'w'), indent=1)
