import numpy as np, time
from sim2 import *
rng = np.random.default_rng(11)
for fl in (4.0, 4.5):
    c = cfgx(taps=[(fl, 1.0)])
    for pol in ('fixed1', 'thresh', 'top', 'window'):
        e, n = run_trials(c, pol, 150, rng, L=3)
        lo, hi = wilson(e, n)
        print('lag', fl, pol, round(e / n, 4), (round(lo, 4), round(hi, 4)))
