import numpy as np
from sim2 import *
rng = np.random.default_rng(33)
P3 = [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)]
P5 = [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)]
lags = list(range(0, 16))
for nm, tp in (('P3', P3), ('P5', P5)):
    c = cfgx(taps=tp, direct=[(1.0, 1.0), (3.1, 0.5)])
    res = {}
    for ntrain in (16, 32):
        for shrink in (0.05, 0.3, 1.0):
            res[(ntrain, shrink)] = [0, 0]
    res['fixed1'] = [0, 0]
    for _ in range(300):
        bits = rng.integers(0, 2, 80)
        ref, ys, PAD, H = simulate_packet(bits, c, rng)
        C = corr_vec(ref, ys, PAD, H, 80, lags)
        Dv = C[:, 0, :] - C[:, 1, :]
        sg = 2 * bits - 1
        te = slice(32, 80)
        det = (Dv[:, 4] > 0).astype(int); res['fixed1'][0] += int(np.sum(det[te] != bits[te])); res['fixed1'][1] += 48
        for ntrain in (16, 32):
            Z = (sg[:ntrain, None] * Dv[:ntrain])
            z = Z.mean(0)
            R = Dv[:ntrain] - sg[:ntrain, None] * z
            S0 = np.cov(R.T)
            for shrink in (0.05, 0.3, 1.0):
                Sg = (1 - 0) * S0 + shrink * np.eye(len(lags)) * np.mean(np.diag(S0))
                w = np.linalg.solve(Sg, z)
                det = (Dv @ w > 0).astype(int)
                res[(ntrain, shrink)][0] += int(np.sum(det[te] != bits[te])); res[(ntrain, shrink)][1] += 48
    print(nm, {str(k): round(v[0] / v[1], 4) for k, v in res.items()})
