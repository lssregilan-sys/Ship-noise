import numpy as np, json, sys, time
from sim2 import *

which = sys.argv[1]
rng = np.random.default_rng({'A': 101, 'B': 202}[which])
t0 = time.time()
R = {}
def log(*a): print(f"[{time.time()-t0:6.0f}s]", *a, flush=True)
def ber(c, pol, nt, **kw):
    e, n = run_trials(c, pol, nt, rng, **kw)
    lo, hi = wilson(e, n)
    return dict(ber=e / n, lo=lo, hi=hi, n=n)

H = 500
KAP = (1 + 3 * .25 + 3 * .0625 / 8) / (1.125) ** 2
def th_corr(g2, sw2=1e-3, kap=KAP):
    rho = 1 / (1 + sw2)
    return float(Q(np.sqrt(H * g2 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2)))))
def th_ed(g2, sw2=1e-3, kap=KAP):
    rho = 1 / (1 + sw2)
    return float(Q(np.sqrt(H * g2 ** 2 * rho ** 2 / (4 * (1 + (kap - 1) * rho ** 2)))))

if which == 'A':
    # E1 baselines: corr vs energy detector
    g2s = [0.011, 0.022, 0.044, 0.088, 0.176, 0.35]
    R['E1'] = dict(g2=g2s, corr=[], ed=[], th_corr=[th_corr(g) for g in g2s], th_ed=[th_ed(g) for g in g2s])
    for g in g2s:
        c = cfgx(g2=g)
        R['E1']['corr'].append(ber(c, 'fixed1', 500))
        R['E1']['ed'].append(ber(c, 'ed', 500))
        log('E1', g, R['E1']['corr'][-1]['ber'], R['E1']['ed'][-1]['ber'])
    # E1b: Manchester vs OOK under level change
    R['E1b'] = {}
    for lv in (0.0, 6.0, 12.0):
        cm = cfgx(g2=0.088, level_db=lv)
        co = cfgx(g2=0.088, level_db=lv, mod='ook')
        R['E1b'][str(lv)] = dict(manchester=ber(cm, 'fixed1', 500), ook=ber(co, 'ook', 500))
        log('E1b', lv, R['E1b'][str(lv)]['manchester']['ber'], R['E1b'][str(lv)]['ook']['ber'])
    # E2 fractional lag
    R['E2'] = {}
    for fl in (0.0, 0.25, 0.5):
        c = cfgx(taps=[(4.0 + fl, 1.0)])
        R['E2'][str(fl)] = dict(fixed1=ber(c, 'fixed1', 800), window3=ber(c, 'window', 800, L=3), thresh=ber(c, 'thresh', 800))
        log('E2', fl, {k: v['ber'] for k, v in R['E2'][str(fl)].items()})
    # E3 multipath
    prof = {
        'P1 (1 tap)': [(4.0, 1.0)],
        'P3 (3 taps)': [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)],
        'P5 (5 taps)': [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)],
    }
    R['E3'] = {}
    for name, tp in prof.items():
        pw = np.array([a * a for _, a in tp]); pw /= pw.sum()
        c = cfgx(taps=tp, direct=[(1.0, 1.0), (3.1, 0.5)])
        R['E3'][name] = dict(pmax=float(pw.max()), fixed1=ber(c, 'fixed1', 800), window3=ber(c, 'window', 800, L=3),
                             window9=ber(c, 'window', 800, L=9), thresh=ber(c, 'thresh', 800))
        log('E3', name, {k: (v['ber'] if isinstance(v, dict) else v) for k, v in R['E3'][name].items()})
    json.dump(R, open('e2_A.json', 'w'), indent=1)

if which == 'B':
    # E4 tracking under lag drift (samples/s); packet = 32 s
    R['E4'] = {}
    for rate in (0.0, 0.1, 0.25, 0.5, 1.0):
        c = cfgx(taps=[(4.0, 1.0)], ramp=rate)
        R['E4'][str(rate)] = dict(fixed1=ber(c, 'fixed1', 400, lags=range(0, 48)),
                                  window3=ber(c, 'window', 400, lags=range(0, 48), L=3),
                                  trackw5=ber(c, 'trackw', 400, lags=range(0, 48), L=5),
                                  track=ber(c, 'track', 400, lags=range(0, 48)))
        log('E4', rate, {k: v['ber'] for k, v in R['E4'][str(rate)].items()})
    # E5 carrier realism, isolating the carrier with aligned integer lag and fixed1
    cases = {
        'Gaussian, 1 harmonic': dict(),
        'heavy-tailed': dict(heavy=True),
        'tonal 10%': dict(tonal=0.1),
        'tonal 30%': dict(tonal=0.3),
        '3 harmonics': dict(mus=[0.5, 0.25, 0.12]),
        'blade-rate drift 5%': dict(drift=0.05),
        'all combined': dict(mus=[0.5, 0.25, 0.12], heavy=True, tonal=0.1, drift=0.05),
    }
    R['E5'] = {}
    for name, kw in cases.items():
        c = cfgx(**kw)
        kap = kappa_h(c['mus'])
        R['E5'][name] = dict(res=ber(c, 'fixed1', 800), kappa=kap, theory=th_corr(0.022, kap=kap))
        log('E5', name, R['E5'][name]['res']['ber'], R['E5'][name]['theory'])
    # E8 node clock quantisation / recovery
    R['E8'] = {}
    sig = 1.7
    def mk(q_ms, free=False):
        def f(rg, nb):
            if free:
                return np.full(nb, int(rg.integers(-125, 126)))
            e = rg.normal(0, sig) + rg.uniform(-q_ms / 2, q_ms / 2) * 2.0 if q_ms > 0 else rg.normal(0, sig)
            return np.full(nb, int(round(e)))
        return f
    for name, fn in {'ideal': lambda rg, nb: np.zeros(nb, int), 'recovered (1.7 samples)': mk(0.0), '+5 ms node resolution': mk(5.0),
                     '+20 ms': mk(20.0), '+50 ms': mk(50.0), '+100 ms': mk(100.0), 'free-running (uniform ±62 ms)': mk(0, free=True)}.items():
        R['E8'][name] = ber(cfgx(), 'fixed1', 800, eps_fn=fn)
        log('E8', name, R['E8'][name]['ber'])
    # E6 multi-node lag-division
    def multi(lags, g2s, rngl, nt):
        errs = tot = 0
        npre = 16
        for _ in range(nt):
            K, fb = 4, 8.0
            Hh = int(round(K * B / fb)); nb = 64; nsym = nb * 2 * Hh; PAD = 64; n = nsym + 2 * PAD + 64
            cfg = cfgx()
            S8 = make_S8(n, cfg, rngl); sw = np.sqrt(cfg['sig_w2'])
            ref = S8[0:n * U:U] + sw * rngl.standard_normal(n)
            ys = tap(S8, n, 1.0) + sw * rngl.standard_normal(n)
            b1bits = None
            for j, (lj, gj) in enumerate(zip(lags, g2s)):
                bits = rngl.integers(0, 2, nb)
                if j == 0: b1bits = bits
                b = np.zeros(n)
                off = int(rngl.integers(-20, 21)) if j > 0 else 0
                for k in range(nb):
                    s0 = PAD + k * 2 * Hh + off
                    a0 = s0 if bits[k] == 1 else s0 + Hh
                    b[max(a0, 0):a0 + Hh] = 1
                ys = ys + np.sqrt(gj) * b * tap(S8, n, lj)
            C = corr_vec(ref, ys, PAD, Hh, nb, [int(round(lags[0]))])
            D = C[:, 0, 0] - C[:, 1, 0]
            det = (D > 0).astype(int)
            errs += int(np.sum(det[npre:] != b1bits[npre:])); tot += nb - npre
        lo, hi = wilson(errs, tot)
        return dict(ber=errs / tot, lo=lo, hi=hi, n=tot)
    R['E6'] = {'distinct': {}, 'spacing': {}}
    for M in (1, 2, 4, 8):
        lags = [4.0 + 4.0 * j for j in range(M)]
        R['E6']['distinct'][str(M)] = multi(lags, [0.022] * M, rng, 500)
        log('E6 M', M, R['E6']['distinct'][str(M)]['ber'])
    for d in (0.0, 0.5, 1.0, 2.0, 4.0):
        R['E6']['spacing'][str(d)] = multi([4.0, 4.0 + d], [0.022, 0.022], rng, 500)
        log('E6 spacing', d, R['E6']['spacing'][str(d)]['ber'])
    # E7 independence of bit errors (BCH block failure vs binomial prediction)
    c = cfgx(g2=0.014)
    n_bits_tot = 0; errs = 0; blk_fail = {3: 0, 5: 0}; blk_n = {3: 0, 5: 0}
    for _ in range(1500):
        bits = rng.integers(0, 2, 64 + 16)
        ref, ys, PAD, Hh = simulate_packet(bits, c, rng)
        C = corr_vec(ref, ys, PAD, Hh, len(bits), [4])
        det = ((C[:, 0, 0] - C[:, 1, 0]) > 0).astype(int)
        e = (det != bits)[16:]
        errs += int(e.sum()); n_bits_tot += len(e)
        for t_, nblk in ((3, 31), (5, 63)):
            if len(e) >= nblk:
                blk_fail[t_] += int(e[:nblk].sum() > t_); blk_n[t_] += 1
    p = errs / n_bits_tot
    R['E7'] = dict(ber=p, n=n_bits_tot,
                   bch31=dict(mc=blk_fail[3] / blk_n[3], pred=bch_block_error(p, 31, 3), n=blk_n[3]),
                   bch63=dict(mc=blk_fail[5] / blk_n[5], pred=bch_block_error(p, 63, 5), n=blk_n[5]))
    log('E7', R['E7'])
    json.dump(R, open('e2_B.json', 'w'), indent=1)
log('done', which)
