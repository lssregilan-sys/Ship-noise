import numpy as np, json, sys, time
from sim2 import *
which = sys.argv[1]
rng = np.random.default_rng({'C': 301, 'D': 302, 'E': 303}[which]); t0 = time.time(); R = {}
def log(*a): print(f"[{time.time()-t0:5.0f}s]", *a, flush=True)
def ber(c, pol, nt, **kw):
    e, n = run_trials(c, pol, nt, rng, **kw); lo, hi = wilson(e, n); return dict(ber=e / n, lo=lo, hi=hi, n=n)
H = 500
def th(g2, kap, sw2=1e-3):
    rho = 1 / (1 + sw2); return float(Q(np.sqrt(H * g2 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2)))))
if which == 'C':
    prof = {'P1': [(4.0, 1.0)], 'P3': [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)],
            'P5': [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)]}
    dirs = {'single direct': [(1.0, 1.0)], 'multipath direct': [(1.0, 1.0), (3.1, 0.5)]}
    for dn, dv in dirs.items():
        for pn, tp in prof.items():
            c = cfgx(taps=tp, direct=dv)
            pw = np.array([a * a for _, a in tp]); pw /= pw.sum()
            R[f'{dn}|{pn}'] = dict(pmax=float(pw.max()), fixed1=ber(c, 'fixed1', 600, lags=range(0, 16)),
                                   thresh=ber(c, 'thresh', 600, lags=range(0, 16)),
                                   whiten=ber(c, 'whiten', 600, lags=range(0, 16), shrink=0.05))
            log(dn, pn, {k: (round(v['ber'], 4) if isinstance(v, dict) else round(v, 2)) for k, v in R[f'{dn}|{pn}'].items()})
if which == 'D':
    cases = {'Gaussian, 1 harmonic': dict(), 'heavy-tailed': dict(heavy=True), 'tonal 10%': dict(tonal=0.1),
             '3 harmonics': dict(mus=[0.5, 0.25, 0.12]), 'blade-rate drift 5%': dict(drift=0.05),
             'all combined': dict(mus=[0.5, 0.25, 0.12], heavy=True, tonal=0.1, drift=0.05)}
    for nm, kw in cases.items():
        c = cfgx(**kw)
        kap = kappa_h(c['mus']) * (float(np.exp(4 * 0.36)) if c['heavy'] else 1.0)
        R[nm] = dict(plain=ber(c, 'fixed1', 800), norm=ber(c, 'fixed1', 800, norm=True), kappa=kap, theory=th(0.022, kap), theory_norm=th(0.022, 1.0))
        log(nm, round(R[nm]['plain']['ber'], 4), round(R[nm]['norm']['ber'], 4), round(R[nm]['theory'], 4), round(R[nm]['theory_norm'], 4))
if which == 'E':
    for ramp in (0.05, 0.1, 0.15, 0.25):
        c = cfgx(g2=0.044, ramp=ramp)
        R[str(ramp)] = dict(fixed1=ber(c, 'fixed1', 300, lags=range(0, 48)),
                            trackt=ber(c, 'trackt', 300, lags=range(0, 48), beta=0.3),
                            batch=ber(c, 'batch', 300, lags=range(0, 48), beta=0.3, blk=16))
        log(ramp, {k: round(v['ber'], 4) for k, v in R[str(ramp)].items()})
json.dump(R, open(f'e3_{which}.json', 'w'), indent=1)
log('done', which)
