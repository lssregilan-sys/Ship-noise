"""Multi-node (lag-division) figure from v3_e6.json: (a) two equal nodes versus lag spacing against Eq. (16),
(b) node-1 error rate with M equal nodes at distinct integer lags, against the (M-1) g^2/2 variance estimate."""
import json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shipscatter import Q, Qinv
plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 200, "legend.frameon": False})
C = ["#1f4e9c", "#d1495b", "#2a9d8f"]
R = json.load(open('v3_e6.json'))
G2 = 0.022
snr = Qinv(R['distinct']['1']['ber']) ** 2           # single-node detection SNR implied by the measured one-node error rate
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.9))
d = np.linspace(0, 4, 400); r = np.abs(np.sinc(d))   # numpy sinc is sin(pi x)/(pi x)
ax[0].plot(d, 0.5 * (Q(np.sqrt(snr) * (1 - r)) + Q(np.sqrt(snr) * (1 + r))), color=C[0], label='Eq. (16)')
sp = sorted(R['spacing'], key=float)
ax[0].plot([float(s) for s in sp], [R['spacing'][s]['ber'] for s in sp], 's', color=C[1], label='simulation')
ax[0].set_xlabel('lag spacing between two nodes (samples)'); ax[0].set_ylabel('bit error rate of node 1'); ax[0].set_title('(a) two equal nodes', fontsize=8); ax[0].legend()
M = np.array([1, 2, 3, 4]); b = np.array([R['distinct'][str(m)]['ber'] for m in M])
lo = np.array([R['distinct'][str(m)]['lo'] for m in M]); hi = np.array([R['distinct'][str(m)]['hi'] for m in M])
ax[1].errorbar(M, b, yerr=[b - lo, hi - b], color=C[0], marker='o', capsize=3, label='simulation')
ax[1].plot(M, Q(np.sqrt(snr / (1 + (M - 1) * G2 / 2))), '--', color=C[2], label='variance estimate')
ax[1].set_xlabel('number of nodes M at integer lags 2-5'); ax[1].set_ylabel('bit error rate of node 1'); ax[1].set_title('(b) up to four nodes', fontsize=8); ax[1].set_xticks(M); ax[1].legend()
fig.tight_layout(); fig.savefig('fig14_multinode.png'); plt.close(fig)
