if True:
    pass
import numpy as np, json
import exp_pass2 as P
from exp_pass import rho_of_R, Lbb, RHO_C, ETA_A, P_ACT, DRX
P.KSET = [2 ** i for i in range(0, 17)]
C0, FS, D = 1500.0, 2000.0, 2.0
LMIN, DRIFT_MAX = 1.0, 0.1
PEN = 1 / 2.31   # SNR penalty when node lag coincides with the direct-path lag (Monte Carlo: BER 0.0033 -> 0.037)
allc = list(P.CODES)

def geom(v, Dc, theta_deg, dt=2.0, half=3000.0):
    t = np.arange(-half / v, half / v, dt); x = v * t
    th = np.deg2rad(theta_deg); u = np.array([np.cos(th), np.sin(th)])
    # receiver at origin, node at D*u, ship at (x, Dc)
    sx, sy = x, np.full_like(x, Dc)
    R = np.hypot(sx, sy); Rn = np.hypot(sx - D * u[0], sy - D * u[1])
    l = FS * (Rn + D - R) / C0
    dl = np.abs(np.gradient(l, t))
    return t, R, l, dl

def rates_for(v, Dc, TS, kap, codes, xl=0.0, dt=2.0, g2s=1.0):
    fb = 1.6 * v
    t = np.arange(-3000 / v, 3000 / v, dt); R = np.sqrt(Dc ** 2 + (v * t) ** 2)
    rho = rho_of_R(R, v, xl); g2 = g2s * 10 ** (TS / 10) / DRX ** 2
    rates = np.array([P.best_slot(lambda K: P.snr_det(P.BW * K / fb, g2, rho[i], kap), fb, codes)[0] for i in range(len(t))])
    SPL = Lbb(v) - 20 * np.log10(R); pPa = 10 ** (SPL / 20) * 1e-6
    E = float((ETA_A * pPa ** 2 / RHO_C).sum() * dt)
    return t, rates, E

def reports(rates, mask, E, dt=2.0, p_act=P_ACT):
    r = rates * mask
    link = float(r.sum() * dt)
    order = np.argsort(-r); cum = np.arange(1, len(r) + 1) * dt
    en = float(r[order][cum <= E / p_act].sum() * dt)
    return link, en

if __name__ == '__main__':
    out = {'orient': [], 'ts': [], 'drift': [], 'frac': []}
    thetas = np.arange(0, 360, 5)
    for v in (5, 8):
        for Dc in (100, 200, 500):
            t, r_unc, E = rates_for(v, Dc, -10, P.KAP_PLAIN, ['uncoded'])
            _, r_cod, _ = rates_for(v, Dc, -10, 1.0, allc)
            row = dict(v=v, Dc=Dc, E_uJ=E * 1e6)
            _, r_unc_p, _ = rates_for(v, Dc, -10, P.KAP_PLAIN, ['uncoded'], g2s=PEN)
            _, r_cod_p, _ = rates_for(v, Dc, -10, 1.0, allc, g2s=PEN)
            ideal = reports(r_cod, np.ones_like(r_cod), E)
            row['ideal'] = dict(link=ideal[0], energy=ideal[1], unc=reports(r_unc, np.ones_like(r_unc), E)[0])
            per = []
            for th in thetas:
                _, R, l, dl = geom(v, Dc, th)
                md = (dl <= DRIFT_MAX).astype(float); coll = l < LMIN
                rc = np.where(coll, r_cod_p, r_cod) * md; ru = np.where(coll, r_unc_p, r_unc) * md
                rx = np.where(coll, 0.0, r_cod) * md
                a = reports(rc, np.ones_like(rc), E); b = reports(ru, np.ones_like(ru), E); x = reports(rx, np.ones_like(rx), E)
                per.append(dict(th=int(th), frac_coll=float(coll.mean()), link=a[0], energy=a[1], unc=b[0], excl=x[0]))
            row['per'] = per
            for th in (0, 90, 180, 270):
                row[f'th{th}'] = next(p for p in per if p['th'] == th)
            row['avg'] = dict(link=float(np.mean([p['link'] for p in per])), energy=float(np.mean([p['energy'] for p in per])),
                              unc=float(np.mean([p['unc'] for p in per])), frac_coll=float(np.mean([p['frac_coll'] for p in per])),
                              min_link=float(min(p['link'] for p in per)), excl=float(np.mean([p['excl'] for p in per])),
                              min_excl=float(min(p['excl'] for p in per)))
            # fraction of orientations for which >=90% of ideal link achieved
            row['good_orient_frac'] = float(np.mean([p['link'] >= 0.9 * ideal[0] for p in per]))
            out['orient'].append(row)
            print(v, Dc, 'ideal', round(ideal[0], 1), 'th0', round(row['th0']['link'], 1), 'th270', round(row['th270']['link'], 1), 'avg', round(row['avg']['link'], 1), 'excl avg', round(row['avg']['excl'], 1), flush=True)
    # TS sweep to -40, 5 m/s, CPA 100, perpendicular axis (best case) and ideal
    for ts in (-10, -15, -20, -25, -30, -35, -40):
        t, r_c, E = rates_for(5, 100, ts, 1.0, allc); _, r_u, _ = rates_for(5, 100, ts, P.KAP_PLAIN, ['uncoded'])
        _, R, l, dl = geom(5, 100, 270); m = (dl <= DRIFT_MAX).astype(float)
        out['ts'].append(dict(ts=ts, coded=reports(r_c, m, E)[0], unc=reports(r_u, m, E)[0]))
        print('ts', ts, out['ts'][-1], flush=True)
    # drift exclusion (true cube law) at theta=0 and 90, and nu_pk
    for Dc in (100, 200):
        for th in (0, 90, 270):
            t, R, l, dl = geom(5, Dc, th)
            out['drift'].append(dict(v=5, Dc=Dc, th=th, max_dl=float(dl.max()), excl_s=float((dl > DRIFT_MAX).sum() * 2.0), low_lag_frac=float((l < LMIN).mean())))
    # analytic far-field usable fraction vs orientation
    cs = np.cos(np.deg2rad(thetas))
    out['frac'] = [dict(th=int(th), approach_ok=bool(1 - 0 >= 0), ) for th in thetas[:1]]
    # direct-transmit baseline
    N0 = 10 ** ((50 - 17 * np.log10(3)) / 10)
    tx = []
    for d in (2, 10, 100, 1000, 5000, 10000):
        rx_dB = 10 * np.log10(10 * N0 * 1.0); SL = rx_dB + 20 * np.log10(d) + 0.2 * d / 1000
        Pac = 10 ** ((SL - 170.8) / 10)
        tx.append(dict(d=d, SL=float(SL), P_ac=float(Pac), P_el=float(Pac / 0.3)))
    out['tx'] = tx
    # plate TS and rate (Eq 9), f=3 kHz
    from scipy.special import erfcinv
    Qinv = lambda p: np.sqrt(2) * erfcinv(2 * p)
    plate = []
    for a in (0.05, 0.1, 0.25, 0.5, 1.0):
        lam = C0 / 3000
        ts_plate = 20 * np.log10(a * a / lam) - 6   # -6 dB: modulation depth (differential) allowance
        for d in (2.0, 0.5):
            g2 = 10 ** (ts_plate / 10) / d ** 2
            rate = 1000 * g2 / (2 * Qinv(1e-3) ** 2 * 1.4)
            plate.append(dict(a=a, d=d, ts=float(ts_plate), g2=float(g2), rate=float(rate)))
    out['plate'] = plate
    json.dump(out, open('v3_results.json', 'w'), indent=1)
