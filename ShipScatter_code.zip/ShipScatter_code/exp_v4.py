"""Pass-level analysis v4: delay-collision penalty (3.6 dB) AND measured tracker loss (1.5 dB at 0.05, 2.1 dB at 0.1 samples/s)."""
import numpy as np, json, sys
import exp_pass2 as P
import exp_v3 as X
from exp_pass import RHO_C, ETA_A, P_ACT, DRX, rho_of_R, Lbb
P.KSET = [2 ** i for i in range(0, 17)]
allc = list(P.CODES)
PEN_DB = 10 * np.log10(2.31)
STEP = 0.75; NG = 9           # total loss grid 0..6 dB
DT = 2.0
def tracker_loss_db(dl):      # measured: 0 at 0, 1.5 dB at 0.05, 2.1 dB at 0.1 samples/s
    return np.interp(dl, [0, 0.05, 0.1], [0, 1.5, 2.1])

def grid(v, Dc, TS, kap, codes, xl=0.0):
    fb = 1.6 * v
    t = np.arange(-3000 / v, 3000 / v, DT); R = np.sqrt(Dc ** 2 + (v * t) ** 2)
    rho = rho_of_R(R, v, xl); g2 = 10 ** (TS / 10) / DRX ** 2
    G = np.zeros((NG, len(t)))
    for k in range(NG):
        s = 10 ** (-STEP * k / 10)
        for i in range(len(t)):
            G[k, i] = P.best_slot(lambda K: P.snr_det(P.BW * K / fb, g2 * s, rho[i], kap), fb, codes)[0]
    SPL = Lbb(v) - 20 * np.log10(R); pPa = 10 ** (SPL / 20) * 1e-6
    E = float((ETA_A * pPa ** 2 / RHO_C).sum() * DT)
    return t, G, E

def evaluate(G, E, l, dl, loss=True, coll=True):
    tot = np.zeros_like(l)
    if loss: tot += tracker_loss_db(np.minimum(dl, 0.1))
    if coll: tot += np.where(l < 1.0, PEN_DB, 0.0)
    idx = np.clip(np.rint(tot / STEP).astype(int), 0, NG - 1)
    r = G[idx, np.arange(len(l))] * (dl <= 0.1)
    link = float(r.sum() * DT)
    order = np.argsort(-r); cum = np.arange(1, len(r) + 1) * DT
    en = float(r[order][cum <= E / P_ACT].sum() * DT)
    return link, en, float((r >= 1 / 600.0).sum() * DT)

if __name__ == '__main__':
    out = {'orient': [], 'ts': [], 'xl': []}
    thetas = np.arange(0, 360, 5)
    for v in (5, 8):
        for Dc in (100, 200, 500):
            tc, Gc, E = grid(v, Dc, -10, 1.0, allc); _, Gu, _ = grid(v, Dc, -10, P.KAP_PLAIN, ['uncoded'])
            ideal = float(Gc[0].sum() * DT); ideal_u = float(Gu[0].sum() * DT)
            per = []
            for th in thetas:
                _, R, l, dl = X.geom(v, Dc, th)
                a = evaluate(Gc, E, l, dl); u = evaluate(Gu, E, l, dl); x = evaluate(Gc, E, l, dl, loss=True, coll=True)
                # bound: collision samples unusable
                lx = np.where(l < 1.0, 1e9, 0.0)
                r = Gc[np.clip(np.rint(tracker_loss_db(np.minimum(dl, 0.1)) / STEP).astype(int), 0, NG - 1), np.arange(len(l))] * (dl <= 0.1) * (l >= 1.0)
                per.append(dict(th=int(th), frac_coll=float((l < 1).mean()), link=a[0], energy=a[1], unc=u[0], excl=float(r.sum() * DT)))
            row = dict(v=v, Dc=Dc, E_uJ=E * 1e6, ideal=dict(link=ideal, unc=ideal_u), per=per)
            for th in (0, 90, 180, 270): row[f'th{th}'] = next(p for p in per if p['th'] == th)
            row['avg'] = dict(link=float(np.mean([p['link'] for p in per])), unc=float(np.mean([p['unc'] for p in per])),
                              min_link=float(min(p['link'] for p in per)), excl=float(np.mean([p['excl'] for p in per])), min_excl=float(min(p['excl'] for p in per)))
            out['orient'].append(row)
            print(v, Dc, 'ideal', round(ideal, 1), 'far', round(row['th270']['link'], 1), 'broad-lane', round(row['th90']['link'], 1), 'avg', round(row['avg']['link'], 1), 'min', round(row['avg']['min_link'], 1), flush=True)
    _, R, l, dl = X.geom(5, 100, 270)
    for ts in (-10, -12, -15, -20, -24, -25, -30, -35, -40, -52):
        tc, Gc, E = grid(5, 100, ts, 1.0, allc); _, Gu, _ = grid(5, 100, ts, P.KAP_PLAIN, ['uncoded'])
        out['ts'].append(dict(ts=ts, coded=evaluate(Gc, E, l, dl)[0], unc=evaluate(Gu, E, l, dl)[0])); print('ts', ts, out['ts'][-1], flush=True)
    for xl in (0, 10, 20, 30, 40):
        row = dict(xl=xl)
        for nm, kap, codes in (('unc_plain', P.KAP_PLAIN, ['uncoded']), ('coded_plain', P.KAP_PLAIN, allc), ('coded_norm', 1.0, allc)):
            tc, G, E = grid(5, 100, -10, kap, codes, xl=float(xl)); a = evaluate(G, E, l, dl)
            row[nm] = dict(link=a[0], window=a[2])
        out['xl'].append(row); print('xl', xl, {k: (round(x['link'], 1), x['window']) for k, x in row.items() if isinstance(x, dict)}, flush=True)
    json.dump(out, open('v4_results.json', 'w'), indent=1)
