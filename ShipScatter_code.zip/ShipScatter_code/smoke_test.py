"""Quick check: sample-level Monte Carlo against the closed-form error rate (Eq. 9)."""
import numpy as np
from shipscatter import ber_point, theory_ber, FB, FS
rng = np.random.default_rng(1)
K, sw2, mu = 4, 1e-3, 0.5
H = K / (2 * FB) * FS
ok = True
for snr_db in (2, 5, 8):
    g2 = 2 * 10 ** (snr_db / 10) / H
    mc = ber_point(K, g2, sw2, mu, 40000, rng); th = theory_ber(K, g2, sw2, mu)
    good = abs(mc - th) <= 4 * np.sqrt(th * (1 - th) / 40000) + 0.002; ok &= good
    print(f"nominal SNR {snr_db} dB: MC {mc:.4f}  theory {th:.4f}  {'OK' if good else 'MISMATCH'}")
print('PASS' if ok else 'FAIL'); raise SystemExit(0 if ok else 1)
