"""Extended ShipScatter simulator: fractional/multipath/drifting lags, realistic carrier, baselines, trackers."""
import numpy as np
from scipy.signal import resample
from scipy.special import erfc, comb

FS = 2000.0
B = 1000.0
U = 8          # fractional-delay oversampling (1/8 sample resolution)


def Q(x):
    return 0.5 * erfc(x / np.sqrt(2))


def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def kappa_h(mus):
    """Fourth-moment penalty for a multi-harmonic modulator, by numerical average over one period."""
    ph = np.linspace(0, 2 * np.pi, 4001)[:-1]
    # harmonics with fixed relative phases 0 (phase affects kappa slightly; use average over random phases)
    rng = np.random.default_rng(0)
    ks = []
    for _ in range(200):
        m = np.ones_like(ph)
        for h, mu in enumerate(mus):
            m = m + mu * np.cos((h + 1) * ph + rng.uniform(0, 2 * np.pi))
        ks.append(np.mean(m ** 4) / np.mean(m ** 2) ** 2)
    return float(np.mean(ks))


DEFAULT = dict(fb=8.0, K=4, mus=[0.5], drift=0.0, heavy=False, tonal=0.0, level_db=0.0,
               sig_w2=1e-3, g2=0.022, taps=[(4.0, 1.0)], direct=[(1.0, 1.0)], ramp=0.0, npre=16, mod='manchester')


def cfgx(**kw):
    c = dict(DEFAULT)
    c.update(kw)
    return c


def make_S8(n, cfg, rng):
    t = np.arange(n) / FS
    T = n / FS
    fb_t = cfg['fb'] * (1 + cfg['drift'] * (t / T - 0.5))
    ph = 2 * np.pi * np.cumsum(fb_t) / FS
    m = np.ones(n)
    for h, mu in enumerate(cfg['mus']):
        m = m + mu * np.cos((h + 1) * ph + rng.uniform(0, 2 * np.pi))
    m = m / np.sqrt(np.mean(m ** 2))
    amp = 10 ** (cfg['level_db'] * (t / T - 0.5) / 20) if cfg['level_db'] != 0 else np.ones(n)
    nu = rng.standard_normal(n)
    nu8 = resample(nu, n * U)
    m8 = np.repeat(m * amp, U)
    if cfg['heavy']:
        blk = 20
        nbk = int(np.ceil(n / blk))
        u = np.exp(0.6 * rng.standard_normal(nbk))
        u /= np.sqrt(np.mean(u ** 2))
        u8 = np.repeat(np.repeat(u, blk)[:n], U)
        nu8 = nu8 * u8
    S8 = m8 * nu8
    tau = cfg['tonal']
    if tau > 0:
        k = np.arange(n * U)
        tone = np.zeros(n * U)
        for _ in range(3):
            f = rng.uniform(100, 900)
            tone += np.cos(2 * np.pi * f * k / (FS * U) + rng.uniform(0, 2 * np.pi))
        tone *= np.sqrt(2 / 3) * np.repeat(amp, U)
        S8 = np.sqrt(1 - tau) * S8 + np.sqrt(tau) * tone
    return S8


def tap(S8, n, lag):
    idx = np.arange(n) * U - np.round(U * np.asarray(lag)).astype(int)
    return S8[np.clip(idx, 0, len(S8) - 1)]


def simulate_packet(bits, cfg, rng, eps=None):
    K, fb = cfg['K'], cfg['fb']
    H = int(round(K * B / fb))
    nb = len(bits)
    nsym = nb * 2 * H
    PAD = 64
    n = nsym + 2 * PAD + 64
    sw = np.sqrt(cfg['sig_w2'])
    S8 = make_S8(n, cfg, rng)
    ref = S8[0:n * U:U] + sw * rng.standard_normal(n)
    ys = np.zeros(n)
    dn = np.sqrt(sum(a * a for _, a in cfg['direct']))
    for (l, a) in cfg['direct']:
        ys += (a / dn) * tap(S8, n, l)
    b = np.zeros(n)
    eps = np.zeros(nb, int) if eps is None else eps
    for k in range(nb):
        s0 = PAD + k * 2 * H + int(eps[k])
        if cfg['mod'] == 'manchester':
            a0 = s0 if bits[k] == 1 else s0 + H
            b[a0:a0 + H] = 1
        else:  # OOK over the whole bit
            if bits[k] == 1:
                b[s0:s0 + 2 * H] = 1
    tt = np.arange(n) / FS
    tn = np.sqrt(sum(a * a for _, a in cfg['taps']))
    scat = np.zeros(n)
    for (l, a) in cfg['taps']:
        scat += (a / tn) * tap(S8, n, l + cfg['ramp'] * tt)
    ys += np.sqrt(cfg['g2']) * b * scat + sw * rng.standard_normal(n)
    return ref, ys, PAD, H


def corr_vec(ref, ys, PAD, H, nb, lags, mod='manchester'):
    nsym = nb * 2 * H
    r = ref[PAD:PAD + nsym]
    out = np.empty((nb, 2, len(lags)))
    for i, l in enumerate(lags):
        p = r * ys[PAD + l:PAD + l + nsym]
        out[:, :, i] = p.reshape(nb, 2, H).sum(axis=2)
    return out


def select_w(z, c=3.0):
    s = 1.4826 * np.median(np.abs(z - np.median(z)))
    thr = c * max(s, 1e-9)
    w = np.where(z > thr, z, 0.0)
    if w.sum() <= 0:
        w = np.zeros_like(z)
        w[int(np.argmax(z))] = 1.0
    return w


def batch_refine(Dvec, bits_pre, det0, blk, iters=2, c=2.5, shrink=0.15):
    """Offline two-pass combiner: re-estimate lag weights (and whiten cross-lag noise) from decided bits in sliding blocks."""
    nb, nl = Dvec.shape
    npre = len(bits_pre)
    det = det0.copy()
    det[:npre] = bits_pre
    half = None if blk is None else blk // 2
    for _ in range(iters):
        sgn = 2 * det - 1
        new = det.copy()
        ks = range(npre, nb)
        cache = None
        for k in ks:
            if blk is None and cache is not None:
                wv = cache
            else:
                lo, hi = (0, nb) if blk is None else (max(0, k - half), min(nb, k + half + 1))
                S = sgn[lo:hi, None] * Dvec[lo:hi]
                z = S.mean(axis=0)
                w = select_w(z, c)
                sel = w > 0
                wv = np.zeros(nl)
                if sel.sum() == 1:
                    wv[sel] = 1.0
                else:
                    R = Dvec[lo:hi][:, sel] - sgn[lo:hi, None] * z[sel]
                    Sg = np.cov(R.T) + shrink * np.eye(int(sel.sum())) * np.mean(np.var(R, axis=0))
                    wv[sel] = np.linalg.solve(Sg, z[sel])
                if blk is None:
                    cache = wv
            new[k] = (Dvec[k] @ wv) > 0
        det = new
    return det


def whiten_decode(Dvec, bits_pre, init_det, iters=3, shrink=0.05):
    """Offline whitened (LCMV-style) multi-lag combiner trained on known preamble + decided bits."""
    nb, nl = Dvec.shape
    npre = len(bits_pre)
    det = init_det.copy()
    det[:npre] = bits_pre
    for _ in range(iters):
        sg = 2 * det - 1
        z = (sg[:, None] * Dvec).mean(0)
        R = Dvec - sg[:, None] * z
        S0 = np.cov(R.T)
        Sg = S0 + shrink * np.eye(nl) * np.mean(np.diag(S0))
        w = np.linalg.solve(Sg, z)
        new = (Dvec @ w > 0).astype(int)
        new[:npre] = bits_pre
        det = new
    return det


def detect(Dvec, bits_pre, policy, L=3, beta=0.15, blk=16, shrink=0.05):
    nb = Dvec.shape[0]
    npre = len(bits_pre)
    sgn = 2 * bits_pre - 1
    z = np.mean(sgn[:, None] * Dvec[:npre], axis=0)
    out = np.empty(nb, int)
    out[:npre] = bits_pre
    if policy == 'fixed1':
        w = np.zeros_like(z)
        w[np.argmax(z)] = 1
        out[npre:] = (Dvec[npre:] @ w) > 0
    elif policy == 'top':
        idx = np.argsort(-z)[:L]
        w = np.zeros_like(z)
        w[idx] = np.maximum(z[idx], 0)
        out[npre:] = (Dvec[npre:] @ w) > 0
    elif policy == 'thresh':   # static, lags selected by a robust significance threshold
        w = select_w(z)
        out[npre:] = (Dvec[npre:] @ w) > 0
    elif policy == 'whiten':
        w0 = select_w(z)
        init = np.zeros(nb, int)
        init[npre:] = (Dvec[npre:] @ w0) > 0
        out = whiten_decode(Dvec, bits_pre, init, shrink=shrink)
    elif policy == 'window':   # static contiguous window of L lags around the preamble peak
        j = int(np.argmax(z))
        lo, hi = max(0, j - L // 2), min(len(z), j + L // 2 + 1)
        w = np.zeros_like(z)
        w[lo:hi] = np.maximum(z[lo:hi], 0)
        out[npre:] = (Dvec[npre:] @ w) > 0
    elif policy == 'trackw':   # decision-directed, contiguous window of L lags around the running peak
        z = z.copy()
        for k in range(npre, nb):
            j = int(np.argmax(z))
            lo, hi = max(0, j - L // 2), min(len(z), j + L // 2 + 1)
            w = np.zeros_like(z)
            w[lo:hi] = np.maximum(z[lo:hi], 0)
            bk = int((Dvec[k] @ w) > 0)
            out[k] = bk
            z = (1 - beta) * z + beta * (2 * bk - 1) * Dvec[k]
    elif policy in ('trackt', 'batch', 'batchs'):   # training-mode init over the preamble, then decision-directed
        z = np.zeros(Dvec.shape[1])
        for k in range(npre):
            z = (1 - 0.35) * z + 0.35 * sgn[k] * Dvec[k]
        for k in range(npre, nb):
            w = select_w(z)
            bk = int((Dvec[k] @ w) > 0)
            out[k] = bk
            z = (1 - beta) * z + beta * (2 * bk - 1) * Dvec[k]
        if policy == 'batch':
            out = batch_refine(Dvec, bits_pre, out, blk)
        elif policy == 'batchs':   # static channel: whole-packet block
            out = batch_refine(Dvec, bits_pre, out, None)
    elif policy == 'track':    # decision-directed, lags re-selected every bit
        z = z.copy()
        for k in range(npre, nb):
            w = select_w(z)
            bk = int((Dvec[k] @ w) > 0)
            out[k] = bk
            z = (1 - beta) * z + beta * (2 * bk - 1) * Dvec[k]
    return out


def env_norm(x, W=64):
    p = x * x
    c = np.cumsum(np.insert(p, 0, 0.0))
    avg = (c[W:] - c[:-W]) / W
    pl = W // 2
    full = np.concatenate([np.full(pl, avg[0]), avg, np.full(len(x) - len(avg) - pl, avg[-1])])
    return x / np.sqrt(full + 1e-12)


def run_trials(cfg, policy, ntrial, rng, nbits=64, lags=range(0, 24), L=3, beta=0.15, eps_fn=None, norm=False, blk=16, shrink=0.05):
    """Return (errors, bits) over payload bits (preamble excluded)."""
    npre = cfg['npre']
    errs = 0
    tot = 0
    lags = list(lags)
    for _ in range(ntrial):
        bits = rng.integers(0, 2, nbits)
        eps = None if eps_fn is None else eps_fn(rng, nbits)
        ref, ys, PAD, H = simulate_packet(bits, cfg, rng, eps)
        if norm:
            ref = env_norm(ref)
            ys = env_norm(ys)
        if policy == 'ed':
            nsym = nbits * 2 * H
            E = (ys[PAD:PAD + nsym] ** 2).reshape(nbits, 2, H).sum(axis=2)
            det = ((E[:, 0] - E[:, 1]) > 0).astype(int)
        elif policy == 'ook':
            C = corr_vec(ref, ys, PAD, H, nbits, [int(round(cfg['taps'][0][0]))])
            lam = C[:, 0, 0] + C[:, 1, 0]   # whole-bit correlation (two halves)
            pre = bits[:npre]
            m1 = lam[:npre][pre == 1].mean() if (pre == 1).any() else 0.0
            m0 = lam[:npre][pre == 0].mean() if (pre == 0).any() else 0.0
            det = (lam > 0.5 * (m1 + m0)).astype(int)
        else:
            C = corr_vec(ref, ys, PAD, H, nbits, lags)
            Dvec = C[:, 0, :] - C[:, 1, :]
            det = detect(Dvec, bits[:npre], policy, L=L, beta=beta, blk=blk, shrink=shrink)
        errs += int(np.sum(det[npre:] != bits[npre:]))
        tot += nbits - npre
    return errs, tot


def bch_block_error(p, n, t):
    k = np.arange(t + 1, n + 1)
    from scipy.special import gammaln
    lc = gammaln(n + 1) - gammaln(k + 1) - gammaln(n - k + 1)
    return float(np.sum(np.exp(lc + k * np.log(max(p, 1e-300)) + (n - k) * np.log(max(1 - p, 1e-300)))))
