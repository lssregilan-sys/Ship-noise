import numpy as np, json
from scipy.special import erfc
from exp_pass import (rho_of_R, Lbb, RHO_C, BW, FC, KSET, DRX, ETA_A, P_ACT)
from sim2 import bch_block_error, Q

KAP_PLAIN = (1 + 3 * .25 + 3 * .0625 / 8) / (1.125) ** 2   # 1.40
CODES = {   # name: (channel bits, success function of raw BER p)
    'uncoded': (36, lambda p: (1 - p) ** 36),
    'BCH(31,16)': (93, lambda p: (1 - bch_block_error(p, 31, 3)) ** 3),
    'BCH(63,36)': (63, lambda p: 1 - bch_block_error(p, 63, 5)),
    'BCH(127,64)': (127, lambda p: 1 - bch_block_error(p, 127, 10)),
}
PRE = 16
PSUCC_MIN = 0.9
acq_x = np.array([-10.0, -3.46, -1.46, 0.54, 2.54, 20.0]); acq_y = np.array([0.0, 0.84, 0.94, 0.993, 1.0, 1.0])
def p_acq(snr_lin): return float(np.interp(10 * np.log10(max(snr_lin, 1e-9)), acq_x, acq_y))

def snr_det(N, g2, rho, kap): return N * g2 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2))

def best_slot(snr_fn, fb, codes):
    """return (report rate [1/s], K, code) maximising delivered reports/s subject to PSUCC_MIN"""
    best = (0.0, 0, None)
    for K in KSET:
        s = snr_fn(K)
        p = float(Q(np.sqrt(s)))
        pa = p_acq(s)
        for cn in codes:
            nch, f = CODES[cn]
            ps = f(p) * pa
            if ps >= PSUCC_MIN:
                rate = ps * (fb / K) / (nch + PRE)
                if rate > best[0]: best = (rate, K, cn)
    return best

def analyse(v, Dc, TS, kap, codes, xl=0.0, half=3000.0, p_act=P_ACT, eta_a=ETA_A, dt=2.0):
    fb = 1.6 * v
    t = np.arange(-half / v, half / v, dt)
    R = np.maximum(np.sqrt(Dc ** 2 + (v * t) ** 2), 5.0)
    rho = rho_of_R(R, v, xl)
    g2 = 10 ** (TS / 10) / DRX ** 2
    rates = np.zeros(len(t)); ks = np.zeros(len(t), int)
    for i in range(len(t)):
        r, K, cn = best_slot(lambda K: snr_det(BW * K / fb, g2, rho[i], kap), fb, codes)
        rates[i] = r; ks[i] = K
    link_reports = float(rates.sum() * dt)
    SPL = Lbb(v) - 20 * np.log10(R); pPa = 10 ** (SPL / 20) * 1e-6
    Ph = eta_a * pPa ** 2 / RHO_C
    E = float(Ph.sum() * dt); T_act = E / p_act
    order = np.argsort(-rates); cum = np.arange(1, len(t) + 1) * dt
    en_reports = float(rates[order][cum <= T_act].sum() * dt)
    return dict(v=v, Dc=Dc, link=link_reports, energy=en_reports, window=float((rates > 0).sum() * dt), E_uJ=E * 1e6)

if __name__ == '__main__':
    out = {'cpa': [], 'xl': [], 'ts': []}
    allc = list(CODES)
    for v in (5, 8):
        for Dc in (10, 20, 50, 100, 200, 500):
            row = dict(v=v, Dc=Dc)
            for nm, kap, codes in (('unc_plain', KAP_PLAIN, ['uncoded']), ('coded_plain', KAP_PLAIN, allc),
                                   ('unc_norm', 1.0, ['uncoded']), ('coded_norm', 1.0, allc)):
                a = analyse(v, Dc, -10, kap, codes)
                row[nm] = dict(link=a['link'], energy=a['energy'], window=a['window'])
            row['E_uJ'] = a['E_uJ']
            out['cpa'].append(row)
            print(v, Dc, {k: (round(x['link'], 1), round(x['energy'], 2)) for k, x in row.items() if isinstance(x, dict)}, flush=True)
    for xl in (0, 10, 20, 30, 40):
        row = dict(xl=xl)
        for nm, kap, codes in (('unc_plain', KAP_PLAIN, ['uncoded']), ('coded_plain', KAP_PLAIN, allc), ('coded_norm', 1.0, allc)):
            a = analyse(5, 100, -10, kap, codes, xl=float(xl))
            row[nm] = dict(link=a['link'], window=a['window'])
        out['xl'].append(row); print('xl', xl, {k: (round(x['link'], 1), x['window']) for k, x in row.items() if isinstance(x, dict)}, flush=True)
    for ts in (-20, -15, -10, -5, 0):
        row = dict(ts=ts)
        for nm, kap, codes in (('unc_plain', KAP_PLAIN, ['uncoded']), ('coded_norm', 1.0, allc)):
            a = analyse(5, 100, ts, kap, codes)
            row[nm] = dict(link=a['link'], window=a['window'])
        out['ts'].append(row); print('ts', ts, {k: round(x['link'], 1) for k, x in row.items() if isinstance(x, dict)}, flush=True)
    json.dump(out, open('pass2_results.json', 'w'), indent=1)
