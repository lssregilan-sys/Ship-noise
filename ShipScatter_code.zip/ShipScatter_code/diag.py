import numpy as np
from sim2 import *
rng = np.random.default_rng(21)
P3 = [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)]
tn = np.sqrt(sum(a * a for _, a in P3))
lags = list(range(0, 16))
def oracle_w():
    w = np.zeros(len(lags))
    for l, a in P3:
        for i, lam in enumerate(lags):
            w[i] += (a / tn) * np.sinc(lam - l)
    return w
w = oracle_w()
print('oracle w', np.round(w, 2))
for name, direct in (('direct single', [(1.0, 1.0)]), ('direct multipath', [(1.0, 1.0), (3.1, 0.5)])):
    c = cfgx(taps=P3, direct=direct)
    res = {'fixed1': [0, 0], 'oracle': [0, 0], 'oracle_top1': [0, 0]}
    for _ in range(400):
        bits = rng.integers(0, 2, 64)
        ref, ys, PAD, H = simulate_packet(bits, c, rng)
        C = corr_vec(ref, ys, PAD, H, 64, lags)
        Dv = C[:, 0, :] - C[:, 1, :]
        for nm, ww in (('fixed1', np.eye(len(lags))[4]), ('oracle', w), ('oracle_top1', np.eye(len(lags))[4] * w[4])):
            det = (Dv @ ww > 0).astype(int)
            res[nm][0] += int(np.sum(det[16:] != bits[16:])); res[nm][1] += 48
    print(name, {k: round(v[0] / v[1], 4) for k, v in res.items()})
