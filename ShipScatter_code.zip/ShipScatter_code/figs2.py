import json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8.5, "axes.grid": True, "grid.alpha": 0.3, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 200, "legend.frameon": False})
C = ["#1f4e9c", "#d1495b", "#2a9d8f", "#e9a03b", "#6a4c93", "#777777"]
A = json.load(open('e2_A.json')); Bj = json.load(open('e2_B.json'))
Cj = json.load(open('e3_C.json')); Dj = json.load(open('e3_D.json')); Ej = json.load(open('e3_E.json'))
P2 = json.load(open('pass2_results.json'))
floor = 3e-4
def y(d): return max(d['ber'], floor)
def err(d): return [[max(d['ber'] - d['lo'], 0)], [max(d['hi'] - d['ber'], 0)]]

# ---- Fig 7: detector baselines ----
e1 = A['E1']
fig, ax = plt.subplots(figsize=(4.8, 3.1))
g = np.array(e1['g2'])
ax.loglog(g, [max(t, floor) for t in e1['th_corr']], '-', color=C[0], label='proposed correlator, theory')
ax.errorbar(g, [y(d) for d in e1['corr']], yerr=np.array([err(d) for d in e1['corr']]).squeeze().T, fmt='o', color=C[0], ms=4, capsize=2, label='proposed correlator, simulation')
ax.loglog(g, [max(t, floor) for t in e1['th_ed']], '-', color=C[1], label='energy detector (no reference), theory')
ax.errorbar(g, [y(d) for d in e1['ed']], yerr=np.array([err(d) for d in e1['ed']]).squeeze().T, fmt='s', color=C[1], ms=4, capsize=2, label='energy detector, simulation')
ax.set_xlabel('backscatter-to-direct power ratio $g^2$'); ax.set_ylabel('bit error rate'); ax.set_ylim(floor, 0.7)
ax.legend(fontsize=7, loc='lower left')
fig.tight_layout(); fig.savefig('fig7_baseline.png'); plt.close(fig)

# ---- Fig 8: robustness (2x2) ----
fig, axs = plt.subplots(2, 2, figsize=(6.4, 5.0))
ax = axs[0, 0]
offs = ['0.0', '0.25', '0.5']; w = 0.26; x = np.arange(3)
for i, (k, lab, c) in enumerate((('fixed1', 'single lag', C[1]), ('window3', '3-lag window', C[0]))):
    ax.bar(x + (i - 0.5) * w * 1.1, [A['E2'][o][k]['ber'] for o in offs], w, color=c, label=lab,
           yerr=np.array([err(A['E2'][o][k]) for o in offs]).squeeze().T, capsize=2)
ax.set_xticks(x); ax.set_xticklabels(['0', '0.25', '0.5']); ax.set_xlabel('fractional lag offset (samples)'); ax.set_ylabel('bit error rate')
ax.set_title('(a) fractional lag', fontsize=8.5); ax.legend(fontsize=7)
ax = axs[0, 1]
lv = ['0.0', '6.0', '12.0']
for i, (k, lab, c) in enumerate((('manchester', 'Manchester (differential)', C[0]), ('ook', 'OOK + threshold', C[1]))):
    ax.bar(np.arange(3) + (i - 0.5) * w * 1.1, [max(A['E1b'][l][k]['ber'], 1e-4) for l in lv], w, color=c, label=lab)
ax.set_yscale('log'); ax.set_xticks(np.arange(3)); ax.set_xticklabels(['0', '6', '12']); ax.set_xlabel('carrier level change over packet (dB)')
ax.set_ylabel('bit error rate'); ax.set_title('(b) modulation', fontsize=8.5); ax.legend(fontsize=7, loc='upper left')
ax = axs[1, 0]
names = list(Dj.keys()); xx = np.arange(len(names))
ax.bar(xx - 0.2, [Dj[n]['plain']['ber'] for n in names], 0.38, color=C[1], label='plain correlator')
ax.bar(xx + 0.2, [Dj[n]['norm']['ber'] for n in names], 0.38, color=C[0], label='envelope-normalised')
short = {'Gaussian, 1 harmonic': 'baseline', 'heavy-tailed': 'heavy\ntails', 'tonal 10%': 'tonal\n10%', '3 harmonics': '3 blade\nharm.', 'blade-rate drift 5%': 'rate drift\n5%', 'all combined': 'all'}
ax.set_xticks(xx); ax.set_xticklabels([short[n] for n in names], fontsize=7); ax.set_ylabel('bit error rate'); ax.set_title('(c) carrier realism', fontsize=8.5); ax.legend(fontsize=7)
ax = axs[1, 1]
e8 = Bj['E8']; keys = ['ideal', 'recovered (1.7 samples)', '+5 ms node resolution', '+20 ms', '+50 ms', '+100 ms', 'free-running (uniform ±62 ms)']
labs = ['ideal', 'recov.', '+5 ms', '+20 ms', '+50 ms', '+100 ms', 'free-\nrun']
ax.bar(np.arange(len(keys)), [e8[k]['ber'] for k in keys], 0.6, color=[C[2], C[0], C[0], C[0], C[3], C[3], C[1]],
       yerr=np.array([err(e8[k]) for k in keys]).squeeze().T, capsize=2)
ax.set_xticks(np.arange(len(keys))); ax.set_xticklabels(labs, fontsize=6.5, rotation=35, ha='right'); ax.set_ylabel('bit error rate'); ax.set_title('(d) node clock quality', fontsize=8.5)
fig.tight_layout(); fig.savefig('fig8_robust.png'); plt.close(fig)

# ---- Fig 9: multipath & tracking ----
fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
ax = axs[0]
keys = list(Cj.keys()); w = 0.26; xx = np.arange(len(keys))
for i, (k, lab, c) in enumerate((('fixed1', 'single lag', C[1]), ('thresh', 'MRC (thresholded)', C[3]), ('whiten', 'whitened multi-lag', C[0]))):
    ax.bar(xx + (i - 1) * w, [Cj[kk][k]['ber'] for kk in keys], w, color=c, label=lab)
lab_x = [kk.replace('single direct|', 'S|').replace('multipath direct|', 'M|') for kk in keys]
ax.set_xticks(xx); ax.set_xticklabels(lab_x, fontsize=7); ax.set_ylabel('bit error rate'); ax.set_yscale('log')
ax.set_xlabel('direct path (S single, M multipath) | backscatter taps'); ax.set_title('(a) multipath', fontsize=8.5); ax.legend(fontsize=6.5, loc='upper left')
ax = axs[1]
rates = list(Ej.keys()); xr = [float(r) for r in rates]
for k, lab, c, m in (('fixed1', 'static single lag', C[1], 'o'), ('trackt', 'decision-directed tracker', C[3], 's'), ('batch', 'tracker + block refinement', C[0], '^')):
    ax.errorbar(xr, [Ej[r][k]['ber'] for r in rates], yerr=np.array([err(Ej[r][k]) for r in rates]).squeeze().T, fmt=m + '-', color=c, ms=4, capsize=2, label=lab)
ax.axhline(0.0026, color='gray', ls=':', lw=1); ax.text(0.052, 0.0034, 'stationary theory', fontsize=6.5, color='gray')
ax.set_yscale('log'); ax.set_xlabel('lag drift (samples per second)'); ax.set_ylabel('bit error rate'); ax.set_title('(b) lag drift', fontsize=8.5); ax.legend(fontsize=6.5, loc='lower right')
fig.tight_layout(); fig.savefig('fig9_multipath_track.png'); plt.close(fig)

# ---- Fig 10: multi-node and coding/reports ----
fig, axs = plt.subplots(1, 2, figsize=(6.4, 3.5), gridspec_kw={'width_ratios': [1, 1.25]})
ax = axs[0]
sp = Bj['E6']['spacing']; ds = [float(k) for k in sp]
from scipy.special import erfc
Qf = lambda z: 0.5 * erfc(z / np.sqrt(2))
snr = 3.9
dd = np.linspace(0, 4, 200)
def pred(d):
    r = abs(np.sinc(d)); return 0.5 * (Qf(np.sqrt(snr) * (1 - r)) + Qf(np.sqrt(snr) * (1 + r)))
ax.plot(dd, pred(dd), '-', color=C[0], label='prediction')
ax.errorbar(ds, [sp[k]['ber'] for k in sp], yerr=np.array([err(sp[k]) for k in sp]).squeeze().T, fmt='o', color=C[1], ms=4, capsize=2, label='simulation')
ax.set_xlabel('lag spacing between two nodes (samples)'); ax.set_ylabel('BER of node 1'); ax.set_title('(a) lag-division crosstalk', fontsize=8.5); ax.legend(fontsize=7)
ax = axs[1]
rows5 = [r for r in P2['cpa'] if r['v'] == 5]; rows8 = [r for r in P2['cpa'] if r['v'] == 8]
cp = [r['Dc'] for r in rows5]
ax.loglog(cp, [r['unc_plain']['link'] for r in rows5], 'k--', lw=1, label='link limit, uncoded')
ax.loglog(cp, [r['coded_norm']['link'] for r in rows5], 'k-', lw=1, label='link limit, coded + normalised')
ax.loglog(cp, [max(r['unc_plain']['energy'], 1e-3) for r in rows5], 's--', color=C[0], ms=3.5, label='harvest-only 5 m/s, uncoded')
ax.loglog(cp, [max(r['coded_norm']['energy'], 1e-3) for r in rows5], 's-', color=C[0], ms=3.5, label='harvest-only 5 m/s, coded + norm.')
ax.loglog(cp, [max(r['unc_plain']['energy'], 1e-3) for r in rows8], 'o--', color=C[1], ms=3.5, label='harvest-only 8 m/s, uncoded')
ax.loglog(cp, [max(r['coded_norm']['energy'], 1e-3) for r in rows8], 'o-', color=C[1], ms=3.5, label='harvest-only 8 m/s, coded + norm.')
ax.axhline(1, color='gray', ls=':', lw=1)
ax.set_ylim(1e-2, 120); ax.set_xlabel('closest point of approach (m)'); ax.set_ylabel('36-bit reports delivered per pass'); ax.set_title('(b) reports per pass', fontsize=8.5)
ax.legend(fontsize=5.8, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2, columnspacing=0.8)
fig.tight_layout(); fig.savefig('fig10_scale_coding.png'); plt.close(fig)

# ---- Fig 11: design map and window vs excess loss ----
from scipy.special import erfcinv
Qinv = lambda p: np.sqrt(2) * erfcinv(2 * p)
fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
ax = axs[0]
TS = np.linspace(-25, 5, 120); d = np.linspace(0.5, 20, 120); T, Dm = np.meshgrid(TS, d)
g2 = 10 ** (T / 10) / Dm ** 2; kap = 1.40
Rb = 1000 * g2 / (2 * Qinv(1e-3) ** 2 * kap)
cs = ax.contourf(T, Dm, np.log10(Rb), levels=np.arange(-3, 1.6, 0.5), cmap='viridis')
cl = ax.contour(T, Dm, np.log10(Rb), levels=[-2, -1, 0, 1], colors='w', linewidths=0.7)
ax.clabel(cl, fmt=lambda v: f'{10**v:g} bit/s', fontsize=6)
ax.plot([-10], [2], 'r*', ms=9); ax.set_yscale('log')
ax.set_xlabel('$TS_{mod}$ (dB re 1 m)'); ax.set_ylabel('node–receiver spacing $d$ (m)'); ax.set_title('(a) achievable rate, Eq. (9)', fontsize=8.5)
fig.colorbar(cs, ax=ax, label='log$_{10}$ rate (bit/s)', pad=0.02)
ax = axs[1]
xl = [r['xl'] for r in P2['xl']]
ax.plot(xl, [r['unc_plain']['window'] for r in P2['xl']], 'o--', color=C[1], ms=4, label='uncoded, plain')
ax.plot(xl, [r['coded_plain']['window'] for r in P2['xl']], 's-', color=C[3], ms=4, label='coded, plain')
ax.plot(xl, [r['coded_norm']['window'] for r in P2['xl']], '^-', color=C[0], ms=4, label='coded + normalised')
ax.set_xlabel('excess propagation loss (dB)'); ax.set_ylabel('report-capable window (s)'); ax.set_title('(b) window vs excess loss (CPA 100 m)', fontsize=8.5); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig('fig11_design.png'); plt.close(fig)
print('ok')
