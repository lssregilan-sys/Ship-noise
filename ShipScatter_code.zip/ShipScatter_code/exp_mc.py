import numpy as np, json, time
from shipscatter import *

rng = np.random.default_rng(2026)
out = {}
t0 = time.time()

# ---------------- E1: BER vs detection SNR (K=4, H=500) ----------------
K = 4
H = K / (2 * FB) * FS
snr_dbs = [0, 2, 4, 6, 8, 10, 12]
e1 = {"snr_db": snr_dbs, "mc_mu0": [], "mc_mu05": [], "th_mu0": [], "th_mu05": []}
for sd in snr_dbs:
    g2 = 2 * 10 ** (sd / 10) / H
    sw2 = 1e-3
    nb = 6000 if sd <= 6 else (30000 if sd <= 10 else 80000)
    e1["mc_mu0"].append(ber_point(K, g2, sw2, 0.0, nb, rng))
    e1["mc_mu05"].append(ber_point(K, g2, sw2, 0.5, nb, rng))
    e1["th_mu0"].append(float(theory_ber(K, g2, sw2, 0.0)))
    e1["th_mu05"].append(float(theory_ber(K, g2, sw2, 0.5)))
    print("E1", sd, e1["mc_mu0"][-1], e1["mc_mu05"][-1], time.time() - t0, flush=True)
out["E1"] = e1

# ---------------- E2: BER vs ship-to-ambient ratio at fixed g (SNR_det=9 dB at rho=1, mu=0.5) ----
g2 = 2 * 10 ** (0.9) / H
xs = [-10, -6, -3, 0, 3, 6, 10, 20]
e2 = {"ship_to_noise_db": xs, "mc": [], "th": []}
for x in xs:
    sw2 = 10 ** (-x / 10)
    e2["mc"].append(ber_point(K, g2, sw2, 0.5, 8000 if x < 6 else 30000, rng))
    e2["th"].append(float(theory_ber(K, g2, sw2, 0.5)))
    print("E2", x, e2["mc"][-1], e2["th"][-1], time.time() - t0, flush=True)
out["E2"] = e2

# ---------------- E3: blade-rate clock recovery ----------------
def est_phase(x, W):
    n = int(W * FS)
    t = np.arange(n) / FS
    e = x[:n] ** 2
    e = e - e.mean()
    c = np.sum(e * np.exp(-2j * np.pi * FB * t))
    return np.angle(c)

def eps_trial(W, sn_db, mu, rng):
    n = int(W * FS)
    S = ship_noise(n, mu, rng)
    s2 = 10 ** (-sn_db / 10)
    node = S + np.sqrt(s2) * rng.standard_normal(n)
    rx = S + np.sqrt(s2) * rng.standard_normal(n)
    d = est_phase(node, W) - est_phase(rx, W)
    d = (d + np.pi) % (2 * np.pi) - np.pi
    return d / (2 * np.pi * FB) * FS  # samples (fractional)

Ws = [2, 4, 8, 16, 32]
e3 = {"W": Ws, "std_samples": {}, "ber": {}}
g2_sync = 2 * 10 ** (1.0) / H     # SNR_det = 10 dB at rho=1 (mu=0 form)
for mu in (0.2, 0.5, 0.8):
    for sn in (10, 0, -5):
        key = f"mu{mu}_sn{sn}"
        e3["std_samples"][key] = []
        for W in Ws:
            eps = np.array([eps_trial(W, sn, mu, rng) for _ in range(300)])
            e3["std_samples"][key].append(float(np.std(eps)))
    print("E3 std mu", mu, time.time() - t0, flush=True)

# packet BER with sync error (mu=0.5), 32-bit packets, K=4 (H=500 samples) -> timing in samples vs H
for sn in (10, 0, -5):
    key = f"sn{sn}"
    e3["ber"][key] = []
    for W in Ws:
        errs = 0; tot = 0
        for _ in range(250):
            eps = int(round(eps_trial(W, sn, 0.5, rng)))
            bits = rng.integers(0, 2, 32)
            sw2 = 10 ** (-sn / 10)
            det, _, _ = run_link(bits, K, np.sqrt(g2_sync), sw2, 0.5, rng, eps=eps)
            errs += int(np.sum(det != bits)); tot += 32
        e3["ber"][key].append(errs / tot)
    print("E3 ber", sn, e3["ber"][key], time.time() - t0, flush=True)
# perfect sync references
e3["ber_perfect"] = {}
for sn in (10, 0, -5):
    sw2 = 10 ** (-sn / 10)
    e3["ber_perfect"][f"sn{sn}"] = ber_point(K, g2_sync, sw2, 0.5, 20000, rng)
    print("E3 perfect", sn, e3["ber_perfect"][f"sn{sn}"], flush=True)
# BER vs fixed timing error (samples), sn=10dB
epss = [0, 10, 25, 50, 100, 150, 200, 250]
e3["eps_samples"] = epss
e3["ber_vs_eps"] = [ber_point(K, g2_sync, 0.1, 0.5, 6000, rng, eps=int(e)) for e in epss]
out["E3"] = e3
print("E3 done", time.time() - t0, flush=True)

# ---------------- E4: lag acquisition with a 16-bit preamble ----------------
def acquire_lag(K, g, sw2, mu, rng, nlag=8, npre=16):
    H = int(round(K / (2 * FB) * FS))
    bits = rng.integers(0, 2, npre)
    # run with generic lags: compute D for every candidate lag
    nb = npre
    n = nb * 2 * H + 64
    S = ship_noise(n + 16, mu, rng)
    sw = np.sqrt(sw2)
    ref = S[8:8 + n] + sw * rng.standard_normal(n)
    pat = np.zeros((nb, 2 * H)); pat[:, :H] = bits[:, None]; pat[:, H:] = 1 - bits[:, None]
    b = np.zeros(n); b[:nb * 2 * H] = pat.reshape(-1)
    y = S[8 - LD:8 - LD + n] + g * b * S[8 - LB:8 - LB + n] + sw * rng.standard_normal(n)
    z = np.zeros(nlag)
    sgn = 2 * bits - 1
    for lam in range(nlag):
        prod = ref[:n - lam] * y[lam:]
        prod = np.concatenate([prod, np.zeros(lam)])[:nb * 2 * H].reshape(nb, 2, H).sum(axis=2)
        D = prod[:, 0] - prod[:, 1]
        z[lam] = np.sum(sgn * D)
    return int(np.argmax(z)) == LB

e4 = {"snr_db": [-2, 0, 2, 4, 6, 8], "p_acq": []}
for sd in e4["snr_db"]:
    g2_ = 2 * 10 ** (sd / 10) / H
    ok = sum(acquire_lag(K, np.sqrt(g2_), 1e-3, 0.5, rng) for _ in range(300))
    e4["p_acq"].append(ok / 300)
    print("E4", sd, e4["p_acq"][-1], flush=True)
out["E4"] = e4

out["kappa05"] = float(kappa(0.5))
json.dump(out, open("mc_results.json", "w"), indent=1)
print("saved", time.time() - t0)
