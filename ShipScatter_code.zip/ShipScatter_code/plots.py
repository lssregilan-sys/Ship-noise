import json, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Polygon, Rectangle, Circle

plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 200, "legend.frameon": False})
C = ["#1f4e9c", "#d1495b", "#2a9d8f", "#e9a03b", "#6a4c93"]
mc = json.load(open("mc_results.json"))
ps = json.load(open("pass_results.json"))

# ---------- Fig 1: system diagram ----------
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.set_xlim(0, 10); ax.set_ylim(0, 4.6); ax.axis("off"); ax.grid(False)
ax.add_patch(Rectangle((0, 3.9), 10, 0.7, color="#cfe3f1"))
ax.text(9.9, 4.25, "sea surface", ha="right", va="center", fontsize=8, color="#44627a")
ax.add_patch(Rectangle((0, 0), 10, 0.18, color="#d9c9a8"))
ship = Polygon([[0.7, 4.0], [3.3, 4.0], [3.0, 3.55], [1.0, 3.55]], color="#444")
ax.add_patch(ship)
ax.add_patch(Rectangle((1.6, 4.0), 0.7, 0.35, color="#666"))
ax.text(2.0, 4.52, "ship of opportunity", ha="center", fontsize=8)
ax.add_patch(Circle((1.5, 3.4), 0.12, color="#c0392b"))
ax.text(0.35, 3.25, "propeller:\nblade-rate AM", fontsize=7, color="#c0392b", ha="left", va="top")
# node
ax.add_patch(Rectangle((6.2, 0.35), 0.5, 0.5, color=C[2]))
ax.text(6.45, 0.05, "ShipScatter node\n(toggles reflection)", ha="center", va="top", fontsize=7.5)
# receiver
ax.add_patch(Rectangle((8.2, 0.35), 0.7, 0.5, color=C[4]))
ax.add_patch(Circle((8.35, 0.95), 0.1, color="k")); ax.add_patch(Circle((8.75, 0.95), 0.1, color="k"))
ax.text(8.55, 0.05, "receiver\n(ref + sensing hydrophone)", ha="center", va="top", fontsize=7.5)
ax.text(8.12, 1.2, "ref", fontsize=7, ha="right"); ax.text(8.9, 1.2, "sense", fontsize=7)

def arrow(a, b, col, ls="-", rad=0.0, lw=1.3):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=9, color=col, lw=lw, ls=ls,
                                 connectionstyle=f"arc3,rad={rad}"))

arrow((1.6, 3.35), (6.25, 0.85), C[0])                 # ship -> node
arrow((6.7, 0.7), (8.25, 0.9), C[1], rad=0.0, lw=1.8)  # node -> rx  (backscatter)
arrow((2.1, 3.3), (8.3, 1.0), C[0], ls="--", rad=-0.1)  # direct ship -> rx
ax.text(3.9, 2.35, "incident ship noise", color=C[0], fontsize=7.5, rotation=-33)
ax.text(5.6, 2.55, "direct path (common to both hydrophones)", color=C[0], fontsize=7, rotation=-17)
ax.text(7.2, 1.35, "backscatter b(t) s(t)", color=C[1], fontsize=7.5, rotation=8)
fig.tight_layout()
fig.savefig("fig1_system.png"); plt.close(fig)

# ---------- Fig 2: BER vs detection SNR ----------
e1 = mc["E1"]
fig, ax = plt.subplots(figsize=(4.6, 3.1))
x = np.linspace(0, 12, 100)
from scipy.special import erfc
Qf = lambda z: 0.5 * erfc(z / np.sqrt(2))
ax.semilogy(x, Qf(np.sqrt(10 ** (x / 10))), color=C[0], lw=1.2, label="theory, stationary carrier")
ax.semilogy(x, Qf(np.sqrt(10 ** (x / 10) / mc["kappa05"])), color=C[1], lw=1.2, label=r"theory, $\mu=0.5$ ($\kappa=1.40$)")
ax.semilogy(e1["snr_db"], e1["mc_mu0"], "o", color=C[0], ms=4, label="Monte Carlo, $\\mu=0$")
ax.semilogy(e1["snr_db"], e1["mc_mu05"], "s", color=C[1], ms=4, label="Monte Carlo, $\\mu=0.5$")
ax.set_xlabel(r"nominal detection SNR $N g^2/2$ (dB)"); ax.set_ylabel("bit error rate")
ax.set_ylim(2e-5, 0.5); ax.legend(fontsize=7.5)
fig.tight_layout(); fig.savefig("fig2_ber_snr.png"); plt.close(fig)

# ---------- Fig 3: BER vs ship-to-ambient ----------
e2 = mc["E2"]
fig, ax = plt.subplots(figsize=(4.6, 3.1))
from shipscatter import theory_ber as _tb
HH = 500; _g2 = 2 * 10 ** 0.9 / HH
xx = np.linspace(-10, 20, 60)
ax.semilogy(xx, [_tb(4, _g2, 10 ** (-x / 10), 0.5) for x in xx], "-", color=C[1], label="theory, Eq. (8)")
ax.semilogy(e2["ship_to_noise_db"], e2["mc"], "s", color=C[1], ms=4, label="Monte Carlo")
ax.set_xlabel("ship-to-ambient power ratio at the hydrophones (dB)"); ax.set_ylabel("bit error rate")
ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig("fig3_ber_rho.png"); plt.close(fig)

# ---------- Fig 4: blade-rate clock recovery ----------
e3 = mc["E3"]
fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
ax = axs[0]
for sn, c in zip((10, 0, -5), (C[0], C[2], C[1])):
    ax.loglog(e3["W"], e3["std_samples"][f"mu0.5_sn{sn}"], "o-", color=c, ms=4, label=f"{sn} dB")
ax.axhline(500 * 0.1, color="gray", ls=":", lw=1)
ax.text(2.1, 55, "10% of half-symbol (50 samples)", fontsize=7, color="gray")
ax.set_xticks([2, 4, 8, 16, 32]); ax.set_xticklabels(["2", "4", "8", "16", "32"]); ax.minorticks_off()
ax.set_xlabel("observation window $W$ (s)"); ax.set_ylabel("node-receiver timing error std (samples)")
ax.legend(title="ship-to-ambient", fontsize=7.5, title_fontsize=7.5); ax.set_title("(a) clock recovery error", fontsize=9)
ax = axs[1]
ax.semilogy(e3["eps_samples"], e3["ber_vs_eps"], "o-", color=C[0], ms=4)
ax.set_xlabel("fixed timing offset (samples; half-symbol = 500)"); ax.set_ylabel("bit error rate")
ax.set_title("(b) BER vs. timing offset", fontsize=9)
fig.tight_layout(); fig.savefig("fig4_sync.png"); plt.close(fig)

# ---------- Fig 5: pass analysis ----------
from exp_pass import pass_analysis
fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
ax = axs[0]
for Dc, c in zip((20, 100, 500), (C[0], C[2], C[1])):
    r = pass_analysis(5, Dc, -10, xl=30.0)
    # rate series is only kept for xl=0 in the dict; recompute directly
    import numpy as _np
    from exp_pass import rho_of_R, KSET, KAP, BW, DRX, Qinv
    v = 5; fb = 1.6 * v
    t = _np.arange(-3000 / v, 3000 / v, 1.0)
    R = _np.maximum(_np.sqrt(Dc ** 2 + (v * t) ** 2), 5.0)
    rho = rho_of_R(R, v, 30.0)
    g2 = 10 ** (-10 / 10) / DRX ** 2
    need = Qinv(1e-3) ** 2
    rate = _np.zeros_like(t)
    for i in range(len(t)):
        for K in KSET:
            if BW * K / fb * g2 * rho[i] ** 2 / (2 * (1 + (KAP - 1) * rho[i] ** 2)) >= need:
                rate[i] = fb / K; break
    ax.plot(t, rate, color=c, label=f"CPA {Dc} m")
ax.set_xlabel("time relative to closest approach (s)"); ax.set_ylabel("reliable rate (bit/s)")
ax.legend(fontsize=7.5); ax.set_title("(a) 5 m/s pass, 30 dB excess loss", fontsize=9)
ax = axs[1]
xl = ps["xl"]; xs = [0, 20, 30, 40, 50]
ax.plot(xs, [r["avail"] for r in xl], "o-", color=C[0])
ax.set_xlabel("excess propagation loss (dB)"); ax.set_ylabel("opportunity window (s)")
ax.set_title("(b) window vs. excess loss (CPA 100 m)", fontsize=9)
fig.tight_layout(); fig.savefig("fig5_pass.png"); plt.close(fig)

# ---------- Fig 6: energy-limited bits per pass ----------
fig, ax = plt.subplots(figsize=(4.8, 3.1))
for v, c in zip((3, 5, 8), (C[2], C[0], C[1])):
    rows = [g for g in ps["grid"] if g["v"] == v]
    ax.loglog([g["Dc"] for g in rows], [g["energy_bits"] if g["energy_bits"] > 0.05 else float('nan') for g in rows], "o-", color=c, ms=4, label=f"harvest-only, {v} m/s")
rows = [g for g in ps["grid"] if g["v"] == 5]
ax.loglog([g["Dc"] for g in rows], [g["link_bits"] for g in rows], "k--", lw=1, label="link limit (5 m/s)")
ax.axhline(32, color="gray", ls=":", lw=1); ax.text(10.5, 37, "one 32-bit report", fontsize=7, color="gray")
ax.set_xlabel("closest point of approach (m)"); ax.set_ylabel("reliable bits per ship pass")
ax.set_ylim(0.1, 6000); ax.legend(fontsize=7, loc="upper right", ncol=2)
fig.tight_layout(); fig.savefig("fig6_energy.png"); plt.close(fig)
print("figs done")
