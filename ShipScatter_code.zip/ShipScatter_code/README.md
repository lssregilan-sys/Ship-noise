# ShipScatter: simulation code (supplementary material)

Code and result files for the manuscript "ShipScatter: ship-radiated noise as the carrier of an acoustic backscatter link for underwater IoT nodes".
Everything is simulation; no recorded data are used. Python 3.11, numpy, scipy, matplotlib (tested with numpy 2.5.3, scipy 1.18.1, matplotlib 3.11.2). Run every script from this directory; each writes its output to the current directory. Random seeds are fixed in the scripts.

## Layout
| File | Role |
|---|---|
| `shipscatter.py` | Core model: blade-rate-modulated ship noise, Manchester backscatter link, differential correlator, closed-form error rate (`theory_ber`, `snr_det`, `kappa`) |
| `sim2.py` | Extended receiver and channel models (envelope-normalised correlator, multi-lag window, whitened multi-lag combiner, decision-directed tracker, multipath, fractional delay, BCH block-error helper, Wilson intervals) |
| `exp_mc.py` | Sample-level Monte Carlo: BER vs detection SNR, BER vs ship-to-ambient ratio, blade-rate clock recovery, lag acquisition → `mc_results.json` |
| `exp2.py A`, `exp2.py B` | Receiver experiments: correlator vs energy detector, Manchester vs OOK under level change, fractional lag, multipath, tracking under lag drift, carrier realism, node clock quantisation/recovery, multi-node lag division, independence of bit errors (BCH block failure vs binomial prediction) → `e2_A.json`, `e2_B.json` |
| `exp3.py C`, `D`, `E` | Further multipath / direct-path-structure cases and receiver ablations (including the whitened multi-lag combiner) → `e3_C.json`, `e3_D.json`, `e3_E.json` |
| `exp_v3_e6.py` | Multi-node lag-division access → `v3_e6.json` |
| `exp_v3c.py`, `exp_v3d.py` | Reference contamination and direct-path delay collision → `v3_contam.json`, `v3_dcoll.json` |
| `exp_pass.py` | Pass-level link budget: geometry, Thorp absorption, delay l(t), reliable rate over a pass → `pass_results.json` |
| `exp_pass2.py` | Pass-level coded and uncoded reports per pass, code and block-length selection → `pass2_results.json` |
| `exp_v3.py`, `exp_v4.py` | Reports per pass with the delay-collision penalty (3.6 dB) and the measured tracker loss: target-strength sweep, drift exclusion, orientation dependence, direct-transmission baseline, plate target strength and rate → `v3_results.json`, `v4_results.json` |
| `plots.py`, `figs2.py`, `figs3.py`, `fig_multinode.py` | Figures from the JSON files (file names `fig1_...` to `fig14_...`; the numbering in the filenames is internal and the figure order in the manuscript differs) |
| `tune*.py`, `diag*.py`, `test*.py` | Receiver parameter tuning, diagnostics and early sanity checks used during development |
| `reference_results/` | The result files and logs behind the manuscript, and the figures as drawn |

## Reproducing
```
pip install numpy scipy matplotlib
python3 smoke_test.py                 # 20 s: checks the Monte Carlo against the closed-form error rate
python3 exp_pass.py; python3 exp_pass2.py; python3 exp_v3.py; python3 exp_v4.py   # about 2.5 min, deterministic
python3 exp_v3c.py; python3 exp_v3d.py; python3 exp_v3_e6.py
python3 exp_mc.py                      # about 1.5 min
python3 exp2.py A; python3 exp2.py B   # about 9-10 min each
python3 exp3.py C; python3 exp3.py D; python3 exp3.py E   # about 4 min, 5 min, 1.5 min
python3 plots.py; python3 figs2.py; python3 figs3.py; python3 fig_multinode.py
```
or `bash run_all.sh` (about 45 min on two CPU cores; the experiments are single-threaded).

## Verification
All experiment scripts were re-run from a clean copy of this directory, and their outputs were compared with `reference_results/`. `exp_pass`, `exp_pass2`, `exp_v3`, `exp_v4`, `exp_v3c`, `exp_v3d`, `exp2 A`, `exp2 B`, `exp3 C`, `exp3 D` and `exp3 E` reproduce the stored JSON files exactly. `exp_mc.py` reproduces every simulated value exactly; only the stored theory columns (`th`, `th_mu05` in `mc_results.json`) differ, because they were written by an earlier version of the closed form. The manuscript curves use `shipscatter.theory_ber`, which `figs3.py` recomputes. `exp_v3_e6.py` was not re-run in the clean-copy check; its stored result is in `reference_results/v3_e6.json` and `fig_multinode.py` redraws the manuscript figure from it.

## Notes for readers
* The simulated sound field is a delay-and-scale model with spherical spreading and Thorp absorption, not a propagation model such as Bellhop. The differential target strength of the node is an assumed parameter that the manuscript sweeps; it has not been measured in water.
* Parameter values are in the manuscript (simulation-parameters table) and at the top of `shipscatter.py` and `exp_pass.py`.
