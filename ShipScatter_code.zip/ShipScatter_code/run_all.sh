#!/usr/bin/env bash
set -e
python3 smoke_test.py
python3 exp_pass.py; python3 exp_pass2.py; python3 exp_v3.py; python3 exp_v4.py
python3 exp_v3c.py; python3 exp_v3d.py; python3 exp_v3_e6.py
python3 exp_mc.py
python3 exp2.py A; python3 exp2.py B
python3 exp3.py C; python3 exp3.py D; python3 exp3.py E
python3 plots.py; python3 figs2.py; python3 figs3.py; python3 fig_multinode.py
