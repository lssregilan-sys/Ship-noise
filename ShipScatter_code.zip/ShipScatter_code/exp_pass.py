import numpy as np, json
from shipscatter import Q, Qinv, kappa

MU = 0.5
KAP = kappa(MU)
BW = 1000.0            # detection bandwidth (Hz)
FC = 3000.0            # centre frequency (Hz)
ALPHA_KMDB = 0.20      # Thorp absorption at 3 kHz (dB/km)
KSET = [1, 2, 4, 8, 16, 32, 64, 128]
PB_TARGET = 1e-3
RHO_C = 1.5e6          # Rayl
P_ACT = 5e-6           # node active power (W)  [assumption]
ETA_A = 1e-3           # harvester efficiency x effective area (m^2) [assumption]
DRX = 2.0              # node-to-receiver distance (m)


def Ls(f, v):          # ship spectrum level, dB re uPa^2/Hz @1m (Ross-type simplified)
    return 155 - 25 * np.log10(f / 100.0) + 60 * np.log10(v / 5.0)


def Namb(f):           # ambient noise spectrum level, dB re uPa^2/Hz
    return 50 - 17 * np.log10(f / 1000.0)


def Lbb(v, f1=20.0, f2=1000.0):   # broadband level @1 m, dB re uPa^2
    f = np.linspace(f1, f2, 4000)
    return 10 * np.log10(np.trapezoid(10 ** (Ls(f, v) / 10), f))


def rho_of_R(R, v, xl=0.0):
    TL = 20 * np.log10(R) + ALPHA_KMDB * R / 1000 + xl
    x = 10 ** ((Ls(FC, v) - TL - Namb(FC)) / 10)
    return x / (1 + x)


def pass_analysis(v, Dc, TS, half_len=3000.0, dt=1.0, pb=PB_TARGET, p_act=P_ACT, eta_a=ETA_A, seg_rx=DRX, xl=0.0):
    fb = 1.6 * v                       # blade rate scales with speed (8 Hz at 5 m/s)
    t = np.arange(-half_len / v, half_len / v, dt)
    R = np.maximum(np.sqrt(Dc ** 2 + (v * t) ** 2), 5.0)
    rho = rho_of_R(R, v, xl)
    g2 = 10 ** (TS / 10) / seg_rx ** 2
    need = Qinv(pb) ** 2                # required detection SNR (linear)
    rate = np.zeros_like(t)
    kbest = np.zeros_like(t)
    for i in range(len(t)):
        for K in KSET:
            N = BW * K / fb
            snr = N * g2 * rho[i] ** 2 / (2 * (1 + (KAP - 1) * rho[i] ** 2))
            if snr >= need:
                rate[i] = fb / K
                kbest[i] = K
                break
    link_bits = float(np.sum(rate) * dt)
    # energy
    SPL = Lbb(v) - 20 * np.log10(R)
    pPa = 10 ** (SPL / 20) * 1e-6
    I = pPa ** 2 / RHO_C
    Ph = eta_a * I
    E_pass = float(np.sum(Ph) * dt)
    T_act = E_pass / p_act
    # level-threshold activation == pick best slots first (incident level monotone in R)
    order = np.argsort(-rate)
    cum_t = np.arange(1, len(t) + 1) * dt
    bits_en = float(np.sum(rate[order][cum_t <= T_act]) * dt) if T_act > 0 else 0.0
    bits_both = min(link_bits, bits_en) if T_act < np.sum(rate > 0) * dt else link_bits
    return dict(v=v, Dc=Dc, TS=TS, link_bits=link_bits, energy_bits=bits_en,
                bits=bits_both, E_pass_uJ=E_pass * 1e6, T_act=float(T_act),
                avail=float(np.sum(rate > 0) * dt), peak_rate=float(rate.max()),
                Pmax_uW=float(Ph.max() * 1e6),
                t=t.tolist() if (v == 5 and TS == -10 and Dc in (20, 100, 500)) else None,
                R=R.tolist() if (v == 5 and TS == -10 and Dc in (20, 100, 500)) else None,
                rate=rate.tolist() if (v == 5 and TS == -10 and Dc in (20, 100, 500)) else None,
                Ph=(Ph * 1e6).tolist() if (v == 5 and TS == -10 and Dc in (20, 100, 500)) else None)


if __name__ == "__main__":
    res = {"grid": [], "ts_sweep": [], "param": dict(MU=MU, KAP=KAP, BW=BW, FC=FC, P_ACT=P_ACT, ETA_A=ETA_A, DRX=DRX, PB=PB_TARGET)}
    for v in (3, 5, 8):
        for Dc in (10, 20, 50, 100, 200, 500, 1000):
            res["grid"].append(pass_analysis(v, Dc, -10))
    for TS in (-20, -15, -10, -5, 0):
        for Dc in (20, 100, 500):
            res["ts_sweep"].append(pass_analysis(5, Dc, TS))
    res["xl"] = [pass_analysis(5, 100, -10, xl=x) for x in (0, 20, 30, 40, 50)]
    res["pact"] = [dict(p_act=p, eta_a=e, **{k: val for k, val in pass_analysis(5, 50, -10, p_act=p, eta_a=e).items() if k in ('bits', 'link_bits', 'energy_bits', 'T_act')})
                   for p in (0.1e-6, 0.5e-6, 1e-6, 5e-6) for e in (1e-3, 1e-2)]
    json.dump(res, open("pass_results.json", "w"))
    for r in res["grid"]:
        print(f"v={r['v']} Dc={r['Dc']:5d} link={r['link_bits']:7.1f} en={r['energy_bits']:7.1f} bits={r['bits']:7.1f} "
              f"Epass={r['E_pass_uJ']:9.1f}uJ Tact={r['T_act']:7.1f}s avail={r['avail']:6.0f}s peak={r['peak_rate']:.2f}bps Pmax={r['Pmax_uW']:.3f}uW")
    print("TS sweep")
    for r in res["ts_sweep"]:
        print(f"TS={r['TS']:4d} Dc={r['Dc']:4d} link={r['link_bits']:7.1f} bits={r['bits']:7.1f} peak={r['peak_rate']:.2f}")
    print("XL sweep")
    for r in res["xl"]:
        print(f"XL link={r['link_bits']:.1f} avail={r['avail']:.0f} peak={r['peak_rate']:.2f}")
    print("Pact sweep")
    for r in res["pact"]:
        print(r)
    print("Lbb(5)", Lbb(5.0), "rho(100m,5)", rho_of_R(100.0, 5.0), "rho(3000)", rho_of_R(3000.0, 5.0))
