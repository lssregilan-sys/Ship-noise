import numpy as np, json, sys, time
from sim2 import *
g = sys.argv[1]
rng = np.random.default_rng({'D': 7, 'M': 8}[g]); t0 = time.time(); out = {}
def b(c, pol, nt, **kw):
    e, n = run_trials(c, pol, nt, rng, **kw); return round(e / n, 4)
if g == 'D':
    for ramp in (0.1, 0.25, 0.5, 1.0):
        c = cfgx(g2=0.044, ramp=ramp)
        out[str(ramp)] = {p: b(c, p, 300, lags=range(0, 48), beta=bt) for p, bt in (('trackt', 0.15), ('trackt', 0.3), ('batch', 0.3))} if False else {
            'trackt_b0.15': b(c, 'trackt', 300, lags=range(0, 48), beta=0.15),
            'trackt_b0.3': b(c, 'trackt', 300, lags=range(0, 48), beta=0.3),
            'batch_b0.3': b(c, 'batch', 300, lags=range(0, 48), beta=0.3, blk=16)}
        print(ramp, out[str(ramp)], f"{time.time()-t0:.0f}s", flush=True)
if g == 'M':
    P3 = [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)]
    P5 = [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)]
    for nm, tp in (('P3', P3), ('P5', P5)):
        c = cfgx(taps=tp, direct=[(1.0, 1.0), (3.1, 0.5)])
        out[nm] = dict(fixed1=b(c, 'fixed1', 400), thresh=b(c, 'thresh', 400), batchs=b(c, 'batchs', 400, beta=0.05))
        print(nm, out[nm], f"{time.time()-t0:.0f}s", flush=True)
json.dump(out, open(f'tune2_{g}.json', 'w'), indent=1)
