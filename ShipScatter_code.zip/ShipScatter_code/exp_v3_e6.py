import numpy as np, json, sys, time
from sim2 import *
rng=np.random.default_rng(303)
t0=time.time()
R={}
def log(*a): print(f'[{time.time()-t0:6.0f}s]',*a,flush=True)
H=500
# E6 multi-node lag-division
def multi(lags, g2s, rngl, nt):
    errs = tot = 0
    npre = 16
    for _ in range(nt):
        K, fb = 4, 8.0
        Hh = int(round(K * B / fb)); nb = 64; nsym = nb * 2 * Hh; PAD = 64; n = nsym + 2 * PAD + 64
        cfg = cfgx()
        S8 = make_S8(n, cfg, rngl); sw = np.sqrt(cfg['sig_w2'])
        ref = S8[0:n * U:U] + sw * rngl.standard_normal(n)
        ys = tap(S8, n, 1.0) + sw * rngl.standard_normal(n)
        b1bits = None
        for j, (lj, gj) in enumerate(zip(lags, g2s)):
            bits = rngl.integers(0, 2, nb)
            if j == 0: b1bits = bits
            b = np.zeros(n)
            off = int(rngl.integers(-20, 21)) if j > 0 else 0
            for k in range(nb):
                s0 = PAD + k * 2 * Hh + off
                a0 = s0 if bits[k] == 1 else s0 + Hh
                b[max(a0, 0):a0 + Hh] = 1
            ys = ys + np.sqrt(gj) * b * tap(S8, n, lj)
        C = corr_vec(ref, ys, PAD, Hh, nb, [int(round(lags[0]))])
        D = C[:, 0, 0] - C[:, 1, 0]
        det = (D > 0).astype(int)
        errs += int(np.sum(det[npre:] != b1bits[npre:])); tot += nb - npre
    lo, hi = wilson(errs, tot)
    return dict(ber=errs / tot, lo=lo, hi=hi, n=tot)
R['E6'] = {'distinct': {}, 'spacing': {}}
for M in (1, 2, 3, 4):
    lags = [4.0, 3.0, 5.0, 2.0][:M]
    R['E6']['distinct'][str(M)] = multi(lags, [0.022] * M, rng, 500)
    log('E6 M', M, R['E6']['distinct'][str(M)]['ber'])
for d in (0.0, 0.5, 1.0, 2.0, 4.0):
    R['E6']['spacing'][str(d)] = multi([4.0, 4.0 + d], [0.022, 0.022], rng, 500)
    log('E6 spacing', d, R['E6']['spacing'][str(d)]['ber'])

json.dump(R['E6'],open('v3_e6.json','w'),indent=1)
