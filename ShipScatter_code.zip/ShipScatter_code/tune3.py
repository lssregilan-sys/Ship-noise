import numpy as np, sys, time
from sim2 import *
rng = np.random.default_rng(55); t0 = time.time()
P3 = [(4.0, 1.0), (6.3, 0.7071), (8.6, 0.5)]
P5 = [(4.0, 1.0), (5.7, 0.794), (7.2, 0.63), (9.1, 0.5), (10.6, 0.398)]
for nm, tp in (('P1', [(4.0, 1.0)]), ('P3', P3), ('P5', P5)):
    c = cfgx(taps=tp, direct=[(1.0, 1.0), (3.1, 0.5)])
    r = {}
    r['fixed1'] = run_trials(c, 'fixed1', 300, rng, lags=range(0, 16))
    for sh in (0.05, 0.15, 0.4):
        r[f'whiten{sh}'] = run_trials(c, 'whiten', 300, rng, lags=range(0, 16), shrink=sh)
    print(nm, {k: round(v[0] / v[1], 4) for k, v in r.items()}, f"{time.time()-t0:.0f}s", flush=True)
