import numpy as np, time
from shipscatter import *
rng = np.random.default_rng(1)
t0 = time.time()
K = 4  # 4 blade periods per bit -> H=500 samples
H = K / (2 * FB) * FS
for mu in (0.0, 0.5):
    for snr_db in (2, 5, 8):
        snr = 10 ** (snr_db / 10)
        # choose g2 so that theory SNR_det at rho~1 (mu=0 form) equals snr: N g2/2 = snr
        g2 = 2 * snr / H
        sig_w2 = 1e-3
        ber = ber_point(K, g2, sig_w2, mu, 3000, rng)
        th = theory_ber(K, g2, sig_w2, mu)
        th0 = theory_ber(K, g2, sig_w2, 0.0)
        print(f"mu={mu} snr={snr_db}dB MC={ber:.4f} theory(kappa)={th:.4f} theory(mu=0)={th0:.4f}")
print(time.time() - t0, "s")
