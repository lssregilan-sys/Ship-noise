import numpy as np, time
from sim2 import *
rng = np.random.default_rng(5)
t0 = time.time()
cfg = cfgx()   # K=4,H=500,g2=0.022, single tap lag 4.0, direct lag 1.0
for pol in ('fixed1', 'top', 'track', 'ed', 'ook'):
    e, n = run_trials(cfg, pol, 40, rng)
    print(pol, e, n, e / n, f"{time.time() - t0:.1f}s")
# theory at operating point
H = 500
kap = (1 + 3 * .25 + 3 * .0625 / 8) / (1 + .125) ** 2
rho = 1 / (1 + 1e-3)
snr = H * 0.022 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2))
print("theory SNR dB", 10 * np.log10(snr), "BER", Q(np.sqrt(snr)))
# fractional lag
for fl in (4.0, 4.25, 4.5):
    c = cfgx(taps=[(fl, 1.0)])
    for pol in ('fixed1', 'top'):
        e, n = run_trials(c, pol, 40, rng)
        print('lag', fl, pol, e / n)
