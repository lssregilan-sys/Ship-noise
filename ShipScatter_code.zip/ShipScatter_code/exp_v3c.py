import numpy as np, json
from shipscatter import ship_noise, FS, FB, LB, LD, Q, snr_det, kappa
from sim2 import wilson
rng = np.random.default_rng(77)
K = 4; H = int(round(K / (2 * FB) * FS))
def link(nb, g, g_r=0.0, pi=0.0, LI=1, sw2=1e-3, mu=0.5, LR=3):
    bits = rng.integers(0, 2, nb); n = nb * 2 * H + 64
    S = ship_noise(n + 16, mu, rng); sw = np.sqrt(sw2)
    pat = np.empty((nb, 2 * H)); pat[:, :H] = bits[:, None]; pat[:, H:] = 1 - bits[:, None]
    b = np.zeros(n); b[:nb * 2 * H] = pat.reshape(-1)
    ref = S[8:8 + n] + g_r * b * S[8 - LR:8 - LR + n] + sw * rng.standard_normal(n)
    y = S[8 - LD:8 - LD + n] + g * b * S[8 - LB:8 - LB + n] + sw * rng.standard_normal(n)
    if pi > 0:   # second ship: b-independent, arrives at reference and sensor with relative lag LB (same as the backscatter lag)
        T = ship_noise(n + 16, mu, rng) * np.sqrt(pi)
        ref = ref + T[8:8 + n]; y = y + T[8 - LI:8 - LI + n]
    prod = ref[:n - LB] * y[LB:]; prod = np.concatenate([prod, np.zeros(LB)])[:nb * 2 * H].reshape(nb, 2, H).sum(axis=2)
    return int(np.sum(((prod[:, 0] - prod[:, 1]) > 0).astype(int) != bits)), nb
g2 = 0.044; g = np.sqrt(g2); out = {}
for name, kw in {'baseline': {}, 'ref hears node, g_r = g': dict(g_r=g), 'ref hears node, g_r = 2g': dict(g_r=2 * g),
                 'second ship, equal power, lag 1': dict(pi=1.0, LI=1), 'second ship, 4x power, lag 1': dict(pi=4.0, LI=1),
                 'second ship, 16x power, lag 1': dict(pi=16.0, LI=1),
                 'second ship, equal power, lag 4 (collision)': dict(pi=1.0, LI=4), 'second ship, 4x power, lag 4 (collision)': dict(pi=4.0, LI=4)}.items():
    e = t = 0
    for _ in range(60):
        a, b_ = link(400, g, **kw); e += a; t += b_
    lo, hi = wilson(e, t); out[name] = dict(ber=e / t, lo=lo, hi=hi, n=t); print(name, e / t, t, flush=True)
json.dump(out, open('v3_contam.json', 'w'), indent=1)
