"""ShipScatter simulation: sample-level Monte Carlo + pass-level analysis."""
import numpy as np
from scipy.special import erfc
import json

FS = 2000.0      # sample rate (Hz) = 2B, B = 1 kHz band (baseband-equivalent real process)
B = 1000.0
FB = 8.0         # blade rate (Hz)
LB = 4           # backscatter lag (samples) relative to reference hydrophone
LD = 1           # direct-path differential lag (samples)


def Q(x):
    return 0.5 * erfc(x / np.sqrt(2))


def Qinv(p):
    from scipy.special import erfcinv
    return np.sqrt(2) * erfcinv(2 * p)


def kappa(mu):
    """Fourth-moment penalty of the blade-rate amplitude modulation, E[m^4]/E[m^2]^2."""
    return (1 + 3 * mu ** 2 + 3 * mu ** 4 / 8) / (1 + mu ** 2 / 2) ** 2


def ship_noise(n, mu, rng, phase=None):
    t = np.arange(n) / FS
    ph = rng.uniform(0, 2 * np.pi) if phase is None else phase
    m = (1 + mu * np.cos(2 * np.pi * FB * t + ph)) / np.sqrt(1 + mu ** 2 / 2)
    return m * rng.standard_normal(n)


def run_link(bits, K, g, sig_w2, mu, rng, eps=0, lag_known=True, s=None):
    """Manchester backscatter link. Returns detected bits.
    K = blade periods per bit; half-symbol H = K/(2 FB) s.
    g = backscatter/direct amplitude ratio; sig_w2 = ambient noise variance (ship power = 1).
    eps = node clock offset in samples (node late by eps)."""
    H = int(round(K / (2 * FB) * FS))
    nb = len(bits)
    n = nb * 2 * H + 64
    S = ship_noise(n + 16, mu, rng) if s is None else s
    sw = np.sqrt(sig_w2)
    ref = S[8:8 + n] + sw * rng.standard_normal(n)
    # pattern on node clock
    pat = np.empty(nb * 2 * H)
    first = np.repeat(bits.astype(float), 2 * H).reshape(nb, 2 * H)
    first[:, :H] = bits[:, None]
    first[:, H:] = 1 - bits[:, None]
    pat = first.reshape(-1)
    b = np.zeros(n)
    L = len(pat)
    if eps >= 0:
        m = min(L, n - eps)
        b[eps:eps + m] = pat[:m]
    else:
        m = L + eps
        b[:m] = pat[-eps:-eps + m]
    y = S[8 - LD:8 - LD + n] + g * b * S[8 - LB:8 - LB + n] + sw * rng.standard_normal(n)
    # correlator at the backscatter lag: ref[n] * y[n+lb]
    prod = ref[:n - LB] * y[LB:]
    prod = np.concatenate([prod, np.zeros(LB)])
    prod = prod[:nb * 2 * H].reshape(nb, 2, H).sum(axis=2)
    D = prod[:, 0] - prod[:, 1]
    return (D > 0).astype(int), D, S


def ber_point(K, g2, sig_w2, mu, nbits, rng, eps=0, chunk=400):
    errs = 0
    tot = 0
    g = np.sqrt(g2)
    while tot < nbits:
        nbc = min(chunk, nbits - tot)
        bits = rng.integers(0, 2, nbc)
        det, _, _ = run_link(bits, K, g, sig_w2, mu, rng, eps=eps)
        errs += int(np.sum(det != bits))
        tot += nbc
    return errs / tot


def snr_det(N, g2, rho, kap):
    """Detection SNR (linear): N = samples per half symbol."""
    return N * g2 * rho ** 2 / (2 * (1 + (kap - 1) * rho ** 2))


def theory_ber(K, g2, sig_w2, mu):
    H = K / (2 * FB) * FS
    rho = 1 / (1 + sig_w2)
    return Q(np.sqrt(snr_det(H, g2, rho, kappa(mu))))
